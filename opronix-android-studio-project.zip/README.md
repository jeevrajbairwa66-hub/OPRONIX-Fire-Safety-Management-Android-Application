# OPRONIX — Fire Safety Solutions (Android)

OPRONIX is a complete, native Android application built with Kotlin, Jetpack Compose, and Material 3 for a fire safety products and services enterprise in India.

---

## 🚒 Key Capabilities

1. **Product Catalogue (15 Certified Ranges)**:
   - ABC Stored Pressure Fire Extinguishers (1kg, 2kg, 4kg, 6kg, 9kg)
   - CO2 Clean Agent Extinguishers (2kg, 4.5kg)
   - Mechanical Foam (AFFF) & Water-type extinguishers
   - Optical Smoke & Rate-of-Rise Heat Detectors
   - Microprocessor Fire Alarm Control Panels & Strobe Hooters
   - Automatic Glass Bulb Fire Sprinklers (68°C) & 30m Fire Hose Reels
   - Oblique Fire Hydrant Landing Valves (IS 5290)
   - Photoluminescent Glow Signage, Emergency LED Lights & Fiberglass Blankets
   - Safety stands, brackets, and accessories

2. **Cart & Tax Invoice Checkout**:
   - Dynamic cart quantity adjustments & item deletion
   - Statutory 18% GST calculation on safety equipment
   - Safe logistics freight calculation
   - Promo coupon engine (`FIRESAFE10` for 10% instant discount)
   - Commercial invoice breakdown with shareable summaries

3. **Field Services & Maintenance**:
   - Cylinder refilling, hydro-testing, and pressure verification
   - Smoke detector & alarm panel wiring and setup
   - Comprehensive fire safety audit requests under NBC 2016 Part 4
   - Real-time service booking tracking with assigned safety engineer credentials

4. **Commercial Quotations**:
   - Turnkey project inquiry builder
   - Itemized commercial estimate proposals
   - PDF proposal export & share intent

5. **Annual Maintenance Contracts (AMC)**:
   - Essential, Commercial Pro, and Industrial Enterprise tiers
   - Quarterly audit tracking and scheduled compliance logs

6. **Role-Based Perspectives (Demo Switcher)**:
   - **Customer**: Browse products, order, request audits, view invoices
   - **Field Technician**: View assigned site visits, customer location, update job status (In Progress → Completed)
   - **Administrator**: Executive KPI dashboard, inventory management (Add/Delete/Stock), order dispatch lifecycle, technician assignment, quote approval

7. **Emergency Guidance & Verified Contacts**:
   - Prominent notice for active fire incidents directing users to **101 (Fire Brigade)** and **112 (National Emergency)**
   - Single-tap dialer for OPRONIX Customer Helpdesk (`+91 98290 88888`), WhatsApp Business, and Office Map navigation

---

## 🛠️ Architecture & Tech Stack

- **UI**: 100% Jetpack Compose + Material 3
- **Design Palette**: Fire Red (`#E53935`), Safety Orange (`#FF8A00`), Deep Charcoal (`#101820`)
- **Architecture**: MVVM with Repository Pattern and reactive `StateFlow`
- **Navigation**: Jetpack Navigation Compose
- **Persistence & Cloud**: Switchable architecture with `DemoRepository` (instant offline sandbox) and `FirebaseRepository` (Cloud Firestore & Auth ready)
- **Minimum SDK**: 26 (Android 8.0 Oreo) | **Target SDK**: 36

---

## 🧪 Unit Tests

Run local unit tests via Gradle:
```bash
gradle :app:testDebugUnitTest
```
Tests cover:
- Cart subtotal, 18% GST statutory calculation, delivery fee, and coupon logic
- Indian phone number (10-digit) and email format validation
- Order placement, tracking notes, and status transition workflows
- Demo repository live CRUD operations
