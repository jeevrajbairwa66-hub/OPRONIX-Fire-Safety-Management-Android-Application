package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.AppContainer
import com.example.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(private val container: AppContainer) : ViewModel() {

    val currentUser: StateFlow<User?> = container.authRepository.currentUser
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val products: StateFlow<List<Product>> = container.productRepository.products
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val orders: StateFlow<List<Order>> = container.orderRepository.orders
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val bookings: StateFlow<List<ServiceBooking>> = container.serviceRepository.bookings
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val quotations: StateFlow<List<Quotation>> = container.quotationRepository.quotations
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val contracts: StateFlow<List<AmcContract>> = container.amcRepository.contracts
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val notifications: StateFlow<List<NotificationItem>> = container.notificationRepository.notifications
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val cartItems: StateFlow<List<CartItem>> = container.cartItems
    val couponCode: StateFlow<String?> = container.appliedCoupon
    val couponDiscount: StateFlow<Double> = container.couponDiscount
    val language: StateFlow<AppLanguage> = container.language

    val companyInfo: CompanyInfo = container.companyInfo

    private val _selectedCategory = MutableStateFlow<ProductCategory?>(null)
    val selectedCategory: StateFlow<ProductCategory?> = _selectedCategory.asStateFlow()

    fun selectCategory(category: ProductCategory?) {
        _selectedCategory.value = category
    }

    fun setLanguage(lang: AppLanguage) {
        container.setLanguage(lang)
    }

    fun toggleLanguage() {
        val next = if (language.value == AppLanguage.ENGLISH) AppLanguage.HINDI else AppLanguage.ENGLISH
        container.setLanguage(next)
    }

    fun switchRole(role: UserRole) {
        viewModelScope.launch {
            container.authRepository.switchRole(role)
        }
    }

    fun updateProfile(name: String, phone: String, company: String, gst: String) {
        viewModelScope.launch {
            container.authRepository.updateProfile(name, phone, company, gst)
        }
    }

    fun addToCart(product: Product, quantity: Int = 1) {
        container.addToCart(product, quantity)
    }

    fun updateCartQuantity(productId: String, quantity: Int) {
        container.updateCartQuantity(productId, quantity)
    }

    fun removeFromCart(productId: String) {
        container.removeFromCart(productId)
    }

    fun applyCoupon(code: String): Boolean {
        return container.applyCoupon(code)
    }

    fun removeCoupon() {
        container.removeCoupon()
    }

    fun placeOrder(address: Address, paymentMethod: PaymentMethod, onComplete: (Order) -> Unit) {
        viewModelScope.launch {
            val result = container.orderRepository.placeOrder(
                items = cartItems.value,
                deliveryAddress = address,
                paymentMethod = paymentMethod,
                discount = couponDiscount.value
            )
            result.getOrNull()?.let { newOrder ->
                container.clearCart()
                onComplete(newOrder)
            }
        }
    }

    fun updateOrderStatus(orderId: String, newStatus: OrderStatus) {
        viewModelScope.launch {
            container.orderRepository.updateOrderStatus(orderId, newStatus)
        }
    }

    fun requestServiceBooking(booking: ServiceBooking, onComplete: () -> Unit) {
        viewModelScope.launch {
            container.serviceRepository.requestBooking(booking)
            onComplete()
        }
    }

    fun updateBookingStatus(bookingId: String, status: BookingStatus, notes: String = "") {
        viewModelScope.launch {
            container.serviceRepository.updateBookingStatus(bookingId, status, notes)
        }
    }

    fun assignTechnician(bookingId: String, techId: String, techName: String, techPhone: String) {
        viewModelScope.launch {
            container.serviceRepository.assignTechnician(bookingId, techId, techName, techPhone)
        }
    }

    fun submitQuotation(quotation: Quotation, onComplete: () -> Unit) {
        viewModelScope.launch {
            container.quotationRepository.submitQuotationRequest(quotation)
            onComplete()
        }
    }

    fun prepareQuotation(quoteId: String, subtotal: Double, gst: Double, grandTotal: Double, notes: String) {
        viewModelScope.launch {
            container.quotationRepository.updateQuotation(
                quoteId = quoteId,
                status = QuotationStatus.QUOTATION_PREPARED,
                subtotal = subtotal,
                gst = gst,
                grandTotal = grandTotal,
                adminNotes = notes
            )
        }
    }

    fun submitAmcInquiry(tier: AmcTier, onComplete: () -> Unit) {
        viewModelScope.launch {
            val user = currentUser.value
            container.amcRepository.submitAmcInquiry(
                customerId = user?.id ?: "usr_demo_1",
                customerName = user?.name ?: "Customer",
                companyName = user?.companyName ?: "Sharma Enterprises",
                tier = tier,
                siteAddress = user?.addresses?.firstOrNull()?.formatted ?: "Sitapura Industrial Area, Jaipur",
                equipmentCount = 20
            )
            onComplete()
        }
    }

    fun addProduct(product: Product) {
        viewModelScope.launch {
            container.productRepository.addProduct(product)
        }
    }

    fun deleteProduct(productId: String) {
        viewModelScope.launch {
            container.productRepository.deleteProduct(productId)
        }
    }

    fun toggleFavorite(productId: String) {
        viewModelScope.launch {
            container.productRepository.toggleFavorite(productId)
        }
    }

    fun markNotificationAsRead(id: String) {
        viewModelScope.launch {
            container.notificationRepository.markAsRead(id)
        }
    }
}

class MainViewModelFactory(private val container: AppContainer) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MainViewModel::class.java)) {
            return MainViewModel(container) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
