package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import com.example.data.AppContainer
import com.example.model.*
import com.example.ui.components.*
import com.example.ui.navigation.Screen
import com.example.ui.screens.*
import com.example.ui.theme.OpronixTheme
import com.example.viewmodel.MainViewModel
import com.example.viewmodel.MainViewModelFactory

class MainActivity : ComponentActivity() {

    private lateinit var container: AppContainer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        container = AppContainer(applicationContext)

        setContent {
            val viewModel: MainViewModel = viewModel(factory = MainViewModelFactory(container))
            OpronixApp(viewModel = viewModel)
        }
    }
}

@Composable
fun OpronixApp(viewModel: MainViewModel) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val products by viewModel.products.collectAsStateWithLifecycle()
    val orders by viewModel.orders.collectAsStateWithLifecycle()
    val bookings by viewModel.bookings.collectAsStateWithLifecycle()
    val quotations by viewModel.quotations.collectAsStateWithLifecycle()
    val contracts by viewModel.contracts.collectAsStateWithLifecycle()
    val notifications by viewModel.notifications.collectAsStateWithLifecycle()
    val cartItems by viewModel.cartItems.collectAsStateWithLifecycle()
    val couponCode by viewModel.couponCode.collectAsStateWithLifecycle()
    val couponDiscount by viewModel.couponDiscount.collectAsStateWithLifecycle()
    val language by viewModel.language.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()

    var showEmergencyDialog by remember { mutableStateOf(false) }
    var showRoleSwitcherDialog by remember { mutableStateOf(false) }

    val unreadNotifs = remember(notifications) { notifications.count { !it.isRead } }

    val isTopLevelRoute = currentRoute in listOf(
        Screen.Home.route,
        Screen.Products.route,
        Screen.Services.route,
        Screen.Orders.route,
        Screen.Profile.route
    )

    val showBars = currentRoute != Screen.Splash.route &&
            currentRoute != Screen.Onboarding.route &&
            currentRoute != Screen.Login.route &&
            currentRoute != Screen.Register.route

    OpronixTheme {
        Scaffold(
            topBar = {
                if (showBars) {
                    val title = when (currentRoute) {
                        Screen.Home.route -> "OPRONIX"
                        Screen.Products.route -> "Equipment Catalogue"
                        Screen.Services.route -> "Safety Services"
                        Screen.Orders.route -> "My Orders"
                        Screen.Profile.route -> "Customer Portal"
                        Screen.Cart.route -> "Shopping Cart"
                        Screen.Checkout.route -> "Checkout"
                        Screen.AdminDashboard.route -> "Admin Dashboard"
                        Screen.TechnicianDashboard.route -> "Technician Portal"
                        else -> "OPRONIX Safety"
                    }

                    OpronixTopAppBar(
                        title = title,
                        currentLanguage = language,
                        onLanguageToggle = { viewModel.toggleLanguage() },
                        userRole = currentUser?.role ?: UserRole.CUSTOMER,
                        onRoleSwitchClick = { showRoleSwitcherDialog = true },
                        unreadNotificationCount = unreadNotifs,
                        onNotificationsClick = { navController.navigate(Screen.Notifications.route) },
                        onEmergencyClick = { showEmergencyDialog = true },
                        showBackButton = !isTopLevelRoute,
                        onBackClick = { navController.popBackStack() }
                    )
                }
            },
            bottomBar = {
                if (showBars && isTopLevelRoute) {
                    OpronixBottomBar(
                        currentRoute = currentRoute,
                        onNavigate = { route ->
                            navController.navigate(route) {
                                popUpTo(Screen.Home.route) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        cartItemCount = cartItems.sumOf { it.quantity }
                    )
                }
            }
        ) { innerPadding ->
            NavHost(
                navController = navController,
                startDestination = Screen.Splash.route,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                // Splash & Onboarding
                composable(Screen.Splash.route) {
                    SplashScreen(
                        onSplashFinished = {
                            navController.navigate(Screen.Onboarding.route) {
                                popUpTo(Screen.Splash.route) { inclusive = true }
                            }
                        }
                    )
                }

                composable(Screen.Onboarding.route) {
                    OnboardingScreen(
                        onFinish = {
                            navController.navigate(Screen.Home.route) {
                                popUpTo(Screen.Onboarding.route) { inclusive = true }
                            }
                        }
                    )
                }

                // Auth
                composable(Screen.Login.route) {
                    LoginScreen(
                        onLoginSuccess = { _, role ->
                            viewModel.switchRole(role)
                            navController.navigate(Screen.Home.route) {
                                popUpTo(Screen.Login.route) { inclusive = true }
                            }
                        },
                        onNavigateToRegister = { navController.navigate(Screen.Register.route) },
                        onGuestLogin = {
                            navController.navigate(Screen.Home.route) {
                                popUpTo(Screen.Login.route) { inclusive = true }
                            }
                        }
                    )
                }

                composable(Screen.Register.route) {
                    RegisterScreen(
                        onRegisterSuccess = { name, email, phone ->
                            viewModel.updateProfile(name, phone, "", "")
                            navController.navigate(Screen.Home.route) {
                                popUpTo(Screen.Register.route) { inclusive = true }
                            }
                        },
                        onNavigateToLogin = { navController.popBackStack() }
                    )
                }

                // Home
                composable(Screen.Home.route) {
                    HomeScreen(
                        userName = currentUser?.name?.substringBefore(" ") ?: "Customer",
                        products = products,
                        onProductClick = { prodId ->
                            navController.navigate(Screen.ProductDetail.createRoute(prodId))
                        },
                        onAddToCart = { prod -> viewModel.addToCart(prod, 1) },
                        onToggleFavorite = { prodId -> viewModel.toggleFavorite(prodId) },
                        onNavigateToCategory = { cat ->
                            viewModel.selectCategory(cat)
                            navController.navigate(Screen.Products.route)
                        },
                        onBookService = { srvType ->
                            navController.navigate(Screen.ServiceBooking.createRoute(srvType.name))
                        },
                        onRequestQuotation = { navController.navigate(Screen.RequestQuotation.route) },
                        onViewAmc = { navController.navigate(Screen.AmcCatalogue.route) },
                        onViewAllProducts = {
                            viewModel.selectCategory(null)
                            navController.navigate(Screen.Products.route)
                        },
                        onViewAllServices = { navController.navigate(Screen.Services.route) },
                        onEmergencyClick = { showEmergencyDialog = true }
                    )
                }

                // Products Tab
                composable(Screen.Products.route) {
                    ProductListScreen(
                        products = products,
                        selectedCategory = selectedCategory,
                        onCategorySelected = { cat -> viewModel.selectCategory(cat) },
                        onProductClick = { prodId ->
                            navController.navigate(Screen.ProductDetail.createRoute(prodId))
                        },
                        onAddToCart = { prod -> viewModel.addToCart(prod, 1) },
                        onToggleFavorite = { prodId -> viewModel.toggleFavorite(prodId) },
                        onOpenCart = { navController.navigate(Screen.Cart.route) },
                        cartItemCount = cartItems.sumOf { it.quantity }
                    )
                }

                // Product Detail
                composable(
                    route = Screen.ProductDetail.route,
                    arguments = listOf(navArgument("productId") { type = NavType.StringType })
                ) { backStackEntry ->
                    val prodId = backStackEntry.arguments?.getString("productId") ?: ""
                    val product = products.find { it.id == prodId } ?: products.firstOrNull()
                    if (product != null) {
                        ProductDetailScreen(
                            product = product,
                            onAddToCart = { prod, qty -> viewModel.addToCart(prod, qty) },
                            onBuyNow = { prod, qty ->
                                viewModel.addToCart(prod, qty)
                                navController.navigate(Screen.Checkout.route)
                            },
                            onRequestQuotation = { navController.navigate(Screen.RequestQuotation.route) },
                            onToggleFavorite = { id -> viewModel.toggleFavorite(id) },
                            onBackClick = { navController.popBackStack() }
                        )
                    }
                }

                // Cart
                composable(Screen.Cart.route) {
                    CartScreen(
                        cartItems = cartItems,
                        couponCode = couponCode,
                        couponDiscount = couponDiscount,
                        onUpdateQuantity = { id, qty -> viewModel.updateCartQuantity(id, qty) },
                        onRemoveItem = { id -> viewModel.removeFromCart(id) },
                        onApplyCoupon = { code -> viewModel.applyCoupon(code) },
                        onRemoveCoupon = { viewModel.removeCoupon() },
                        onProceedToCheckout = { navController.navigate(Screen.Checkout.route) },
                        onContinueShopping = { navController.navigate(Screen.Products.route) }
                    )
                }

                // Checkout
                composable(Screen.Checkout.route) {
                    CheckoutScreen(
                        user = currentUser,
                        cartItems = cartItems,
                        couponDiscount = couponDiscount,
                        onPlaceOrder = { address, paymentMethod ->
                            viewModel.placeOrder(address, paymentMethod) { order ->
                                navController.navigate(Screen.OrderDetail.createRoute(order.id)) {
                                    popUpTo(Screen.Cart.route) { inclusive = true }
                                }
                            }
                        },
                        onBackClick = { navController.popBackStack() }
                    )
                }

                // Services Tab
                composable(Screen.Services.route) {
                    ServicesScreen(
                        bookings = bookings,
                        onSelectServiceToBook = { srv ->
                            navController.navigate(Screen.ServiceBooking.createRoute(srv.name))
                        },
                        onViewBookingTracking = { id ->
                            navController.navigate(Screen.ServiceTracking.createRoute(id))
                        }
                    )
                }

                // Service Booking Form
                composable(
                    route = Screen.ServiceBooking.route,
                    arguments = listOf(navArgument("serviceType") { type = NavType.StringType })
                ) { backStackEntry ->
                    val typeStr = backStackEntry.arguments?.getString("serviceType") ?: ServiceType.EXTINGUISHER_REFILLING.name
                    val serviceType = try { ServiceType.valueOf(typeStr) } catch (e: Exception) { ServiceType.EXTINGUISHER_REFILLING }

                    ServiceBookingScreen(
                        serviceType = serviceType,
                        user = currentUser,
                        onSubmitBooking = { booking ->
                            viewModel.requestServiceBooking(booking) {
                                navController.navigate(Screen.ServiceTracking.createRoute(booking.id)) {
                                    popUpTo(Screen.Services.route)
                                }
                            }
                        },
                        onBackClick = { navController.popBackStack() }
                    )
                }

                // Service Tracking
                composable(
                    route = Screen.ServiceTracking.route,
                    arguments = listOf(navArgument("bookingId") { type = NavType.StringType })
                ) { backStackEntry ->
                    val bookingId = backStackEntry.arguments?.getString("bookingId") ?: ""
                    val booking = bookings.find { it.id == bookingId } ?: bookings.firstOrNull()
                    if (booking != null) {
                        ServiceTrackingScreen(
                            booking = booking,
                            onBackClick = { navController.popBackStack() }
                        )
                    }
                }

                // Orders Tab
                composable(Screen.Orders.route) {
                    OrdersScreen(
                        orders = orders,
                        onViewOrderDetails = { orderId ->
                            navController.navigate(Screen.OrderDetail.createRoute(orderId))
                        }
                    )
                }

                // Order Details
                composable(
                    route = Screen.OrderDetail.route,
                    arguments = listOf(navArgument("orderId") { type = NavType.StringType })
                ) { backStackEntry ->
                    val orderId = backStackEntry.arguments?.getString("orderId") ?: ""
                    val order = orders.find { it.id == orderId } ?: orders.firstOrNull()
                    if (order != null) {
                        OrderDetailScreen(
                            order = order,
                            onCancelOrder = { id -> viewModel.updateOrderStatus(id, OrderStatus.CANCELLED) },
                            onBackClick = { navController.popBackStack() }
                        )
                    }
                }

                // Quotations
                composable(Screen.RequestQuotation.route) {
                    RequestQuotationScreen(
                        user = currentUser,
                        preselectedProduct = null,
                        onSubmitQuotation = { quote ->
                            viewModel.submitQuotation(quote) {
                                navController.navigate(Screen.QuotationDetail.createRoute(quote.id)) {
                                    popUpTo(Screen.Home.route)
                                }
                            }
                        },
                        onBackClick = { navController.popBackStack() }
                    )
                }

                composable(
                    route = Screen.QuotationDetail.route,
                    arguments = listOf(navArgument("quoteId") { type = NavType.StringType })
                ) { backStackEntry ->
                    val quoteId = backStackEntry.arguments?.getString("quoteId") ?: ""
                    val quote = quotations.find { it.id == quoteId } ?: quotations.firstOrNull()
                    if (quote != null) {
                        QuotationDetailScreen(
                            quotation = quote,
                            onBackClick = { navController.popBackStack() }
                        )
                    }
                }

                // AMC
                composable(Screen.AmcCatalogue.route) {
                    AmcCatalogueScreen(
                        contracts = contracts,
                        onRequestAmc = { tier ->
                            viewModel.submitAmcInquiry(tier) {
                                navController.navigate(Screen.Profile.route)
                            }
                        },
                        onBackClick = { navController.popBackStack() }
                    )
                }

                // Profile Tab
                composable(Screen.Profile.route) {
                    ProfileScreen(
                        user = currentUser,
                        onSwitchRoleClick = { showRoleSwitcherDialog = true },
                        onNavigateToOrders = { navController.navigate(Screen.Orders.route) },
                        onNavigateToServices = { navController.navigate(Screen.Services.route) },
                        onNavigateToQuotations = {
                            if (quotations.isNotEmpty()) {
                                navController.navigate(Screen.QuotationDetail.createRoute(quotations.first().id))
                            } else {
                                navController.navigate(Screen.RequestQuotation.route)
                            }
                        },
                        onNavigateToAmc = { navController.navigate(Screen.AmcCatalogue.route) },
                        onNavigateToNotifications = { navController.navigate(Screen.Notifications.route) },
                        onNavigateToContact = { navController.navigate(Screen.ContactSupport.route) },
                        onNavigateToAdmin = { navController.navigate(Screen.AdminDashboard.route) },
                        onNavigateToTechnician = { navController.navigate(Screen.TechnicianDashboard.route) },
                        onLogout = { navController.navigate(Screen.Login.route) },
                        onUpdateProfile = { n, p, c, g -> viewModel.updateProfile(n, p, c, g) },
                        onEmergencyClick = { showEmergencyDialog = true }
                    )
                }

                // Contact & Notifications
                composable(Screen.ContactSupport.route) {
                    ContactSupportScreen(
                        companyInfo = viewModel.companyInfo,
                        onBackClick = { navController.popBackStack() }
                    )
                }

                composable(Screen.Notifications.route) {
                    NotificationsScreen(
                        notifications = notifications,
                        onMarkAsRead = { id -> viewModel.markNotificationAsRead(id) },
                        onBackClick = { navController.popBackStack() }
                    )
                }

                // Admin Screens
                composable(Screen.AdminDashboard.route) {
                    AdminDashboardScreen(
                        orders = orders,
                        products = products,
                        bookings = bookings,
                        quotations = quotations,
                        onNavigateToProductManage = { navController.navigate(Screen.AdminProducts.route) },
                        onNavigateToOrderManage = { navController.navigate(Screen.AdminOrders.route) },
                        onNavigateToServiceManage = { navController.navigate(Screen.AdminServices.route) },
                        onNavigateToQuotationManage = { navController.navigate(Screen.AdminQuotations.route) },
                        onBackClick = { navController.popBackStack() }
                    )
                }

                composable(Screen.AdminProducts.route) {
                    AdminProductManageScreen(
                        products = products,
                        onAddProduct = { prod -> viewModel.addProduct(prod) },
                        onDeleteProduct = { id -> viewModel.deleteProduct(id) },
                        onBackClick = { navController.popBackStack() }
                    )
                }

                composable(Screen.AdminOrders.route) {
                    AdminOrderManageScreen(
                        orders = orders,
                        onUpdateStatus = { id, st -> viewModel.updateOrderStatus(id, st) },
                        onBackClick = { navController.popBackStack() }
                    )
                }

                composable(Screen.AdminServices.route) {
                    AdminServiceManageScreen(
                        bookings = bookings,
                        onAssignTechnician = { bId, tId, name, phone ->
                            viewModel.assignTechnician(bId, tId, name, phone)
                        },
                        onBackClick = { navController.popBackStack() }
                    )
                }

                composable(Screen.AdminQuotations.route) {
                    AdminQuotationManageScreen(
                        quotations = quotations,
                        onPrepareQuote = { qId, sub, gst, grand, notes ->
                            viewModel.prepareQuotation(qId, sub, gst, grand, notes)
                        },
                        onBackClick = { navController.popBackStack() }
                    )
                }

                // Technician Dashboard
                composable(Screen.TechnicianDashboard.route) {
                    TechnicianDashboardScreen(
                        bookings = bookings,
                        onUpdateStatus = { id, st, notes -> viewModel.updateBookingStatus(id, st, notes) },
                        onBackClick = { navController.popBackStack() }
                    )
                }
            }
        }
    }

    if (showEmergencyDialog) {
        EmergencyDialog(onDismiss = { showEmergencyDialog = false })
    }

    if (showRoleSwitcherDialog) {
        RoleSwitcherDialog(
            currentRole = currentUser?.role ?: UserRole.CUSTOMER,
            onRoleSelected = { newRole ->
                viewModel.switchRole(newRole)
                when (newRole) {
                    UserRole.CUSTOMER -> navController.navigate(Screen.Home.route)
                    UserRole.TECHNICIAN -> navController.navigate(Screen.TechnicianDashboard.route)
                    UserRole.ADMIN -> navController.navigate(Screen.AdminDashboard.route)
                }
            },
            onDismiss = { showRoleSwitcherDialog = false }
        )
    }
}
