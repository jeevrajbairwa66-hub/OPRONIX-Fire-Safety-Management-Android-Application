package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.UserRole
import com.example.ui.theme.*

@Composable
fun LoginScreen(
    onLoginSuccess: (email: String, role: UserRole) -> Unit,
    onNavigateToRegister: () -> Unit,
    onGuestLogin: () -> Unit
) {
    var email by remember { mutableStateOf("rajesh.sharma@example.com") }
    var password by remember { mutableStateOf("Safety@123") }
    var selectedRole by remember { mutableStateOf(UserRole.CUSTOMER) }
    var isPasswordVisible by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CharcoalBlack)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(24.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(20.dp))

        // Brand Emblem
        Box(
            modifier = Modifier
                .size(76.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(Brush.linearGradient(listOf(FireRed, SafetyOrange))),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.LocalFireDepartment,
                contentDescription = "OPRONIX Logo",
                tint = NeutralWhite,
                modifier = Modifier.size(44.dp)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "Welcome to OPRONIX",
            color = NeutralWhite,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold
        )

        Text(
            text = "Sign in to manage fire protection & orders",
            color = NeutralGray400,
            fontSize = 13.sp
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Role Selector for quick demo testing
        Text(
            text = "Select Account Role (Demo Access)",
            color = SafetyOrangeLight,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            UserRole.values().forEach { role ->
                val isSelected = selectedRole == role
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (isSelected) FireRed else CharcoalCard,
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (isSelected) FireRedLight else CharcoalBorder
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .clickable { selectedRole = role }
                        .testTag("role_select_${role.name}")
                ) {
                    Text(
                        text = when (role) {
                            UserRole.CUSTOMER -> "Customer"
                            UserRole.TECHNICIAN -> "Technician"
                            UserRole.ADMIN -> "Admin"
                        },
                        color = if (isSelected) NeutralWhite else NeutralGray400,
                        fontSize = 12.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(vertical = 10.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Email Field
        OutlinedTextField(
            value = email,
            onValueChange = { email = it; errorMessage = null },
            label = { Text("Email Address") },
            leadingIcon = {
                Icon(Icons.Default.Email, contentDescription = null, tint = NeutralGray400)
            },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = FireRed,
                unfocusedBorderColor = CharcoalBorder,
                focusedLabelColor = FireRedLight,
                unfocusedLabelColor = NeutralGray400,
                focusedTextColor = NeutralWhite,
                unfocusedTextColor = NeutralWhite
            ),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("login_email_input")
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Password Field
        OutlinedTextField(
            value = password,
            onValueChange = { password = it; errorMessage = null },
            label = { Text("Password") },
            leadingIcon = {
                Icon(Icons.Default.Lock, contentDescription = null, tint = NeutralGray400)
            },
            trailingIcon = {
                IconButton(onClick = { isPasswordVisible = !isPasswordVisible }) {
                    Icon(
                        imageVector = if (isPasswordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                        contentDescription = "Toggle Password",
                        tint = NeutralGray400
                    )
                }
            },
            visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = FireRed,
                unfocusedBorderColor = CharcoalBorder,
                focusedLabelColor = FireRedLight,
                unfocusedLabelColor = NeutralGray400,
                focusedTextColor = NeutralWhite,
                unfocusedTextColor = NeutralWhite
            ),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("login_password_input")
        )

        errorMessage?.let {
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = it, color = FireRedLight, fontSize = 12.sp)
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Sign In Button
        Button(
            onClick = {
                if (email.isBlank() || !email.contains("@")) {
                    errorMessage = "Please enter a valid email address."
                } else if (password.length < 4) {
                    errorMessage = "Password must be at least 4 characters."
                } else {
                    onLoginSuccess(email, selectedRole)
                }
            },
            colors = ButtonDefaults.buttonColors(containerColor = FireRed),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .testTag("sign_in_button")
        ) {
            Text(
                text = "Sign In as ${selectedRole.name.lowercase().replaceFirstChar { it.uppercase() }}",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = NeutralWhite
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Guest Access
        OutlinedButton(
            onClick = onGuestLogin,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("guest_login_button")
        ) {
            Text(
                text = "Explore as Guest (Full Catalogue)",
                color = NeutralWhite,
                fontSize = 14.sp
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(text = "Don't have an account? ", color = NeutralGray400, fontSize = 13.sp)
            Text(
                text = "Sign Up",
                color = SafetyOrangeLight,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .clickable { onNavigateToRegister() }
                    .testTag("go_to_register_button")
            )
        }
    }
}

@Composable
fun RegisterScreen(
    onRegisterSuccess: (name: String, email: String, phone: String) -> Unit,
    onNavigateToLogin: () -> Unit
) {
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var companyName by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CharcoalBlack)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(24.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onNavigateToLogin) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = NeutralWhite)
            }
            Text(
                text = "Create Customer Account",
                color = NeutralWhite,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = name,
            onValueChange = { name = it; errorMessage = null },
            label = { Text("Full Name *") },
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = FireRed,
                unfocusedBorderColor = CharcoalBorder,
                focusedTextColor = NeutralWhite,
                unfocusedTextColor = NeutralWhite
            ),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("reg_name_input")
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = email,
            onValueChange = { email = it; errorMessage = null },
            label = { Text("Email Address *") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = FireRed,
                unfocusedBorderColor = CharcoalBorder,
                focusedTextColor = NeutralWhite,
                unfocusedTextColor = NeutralWhite
            ),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("reg_email_input")
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = phone,
            onValueChange = { phone = it; errorMessage = null },
            label = { Text("Phone Number (+91) *") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = FireRed,
                unfocusedBorderColor = CharcoalBorder,
                focusedTextColor = NeutralWhite,
                unfocusedTextColor = NeutralWhite
            ),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("reg_phone_input")
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = companyName,
            onValueChange = { companyName = it },
            label = { Text("Company / Establishment (Optional)") },
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = FireRed,
                unfocusedBorderColor = CharcoalBorder,
                focusedTextColor = NeutralWhite,
                unfocusedTextColor = NeutralWhite
            ),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = password,
            onValueChange = { password = it; errorMessage = null },
            label = { Text("Create Password *") },
            visualTransformation = PasswordVisualTransformation(),
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = FireRed,
                unfocusedBorderColor = CharcoalBorder,
                focusedTextColor = NeutralWhite,
                unfocusedTextColor = NeutralWhite
            ),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("reg_password_input")
        )

        errorMessage?.let {
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = it, color = FireRedLight, fontSize = 12.sp)
        }

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = {
                if (name.isBlank()) {
                    errorMessage = "Please enter your full name."
                } else if (!email.contains("@")) {
                    errorMessage = "Please enter a valid email."
                } else if (phone.length < 10) {
                    errorMessage = "Please enter a valid 10-digit phone number."
                } else if (password.length < 4) {
                    errorMessage = "Password must be at least 4 characters."
                } else {
                    onRegisterSuccess(name, email, phone)
                }
            },
            colors = ButtonDefaults.buttonColors(containerColor = FireRed),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .testTag("submit_register_button")
        ) {
            Text("Register Account", fontWeight = FontWeight.Bold, color = NeutralWhite)
        }
    }
}
