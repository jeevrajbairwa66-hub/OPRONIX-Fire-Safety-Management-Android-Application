package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.*
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ProfileScreen(
    user: User?,
    onSwitchRoleClick: () -> Unit,
    onNavigateToOrders: () -> Unit,
    onNavigateToServices: () -> Unit,
    onNavigateToQuotations: () -> Unit,
    onNavigateToAmc: () -> Unit,
    onNavigateToNotifications: () -> Unit,
    onNavigateToContact: () -> Unit,
    onNavigateToAdmin: () -> Unit,
    onNavigateToTechnician: () -> Unit,
    onLogout: () -> Unit,
    onUpdateProfile: (name: String, phone: String, company: String, gst: String) -> Unit,
    onEmergencyClick: () -> Unit
) {
    var showEditProfileDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CharcoalBlack)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text(
            text = "Customer Dashboard",
            color = NeutralWhite,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "Manage account, enterprise profile and safety compliance",
            color = NeutralGray400,
            fontSize = 12.sp
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Profile Identity Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = CharcoalCard),
            border = androidx.compose.foundation.BorderStroke(1.dp, CharcoalBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                                .background(FireRed),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = user?.name?.take(1) ?: "U",
                                color = NeutralWhite,
                                fontWeight = FontWeight.Bold,
                                fontSize = 22.sp
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column {
                            Text(
                                text = user?.name ?: "Customer",
                                color = NeutralWhite,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                            Text(
                                text = user?.phone ?: "+91 98290 12345",
                                color = NeutralGray400,
                                fontSize = 12.sp
                            )
                            Text(
                                text = user?.email ?: "rajesh@example.com",
                                color = NeutralGray400,
                                fontSize = 11.sp
                            )
                        }
                    }

                    IconButton(onClick = { showEditProfileDialog = true }) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit Profile", tint = SafetyOrangeLight)
                    }
                }

                if (user?.companyName?.isNotBlank() == true) {
                    HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = CharcoalBorder)
                    Text(text = "Enterprise: ${user.companyName}", color = NeutralWhite, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Text(text = "GSTIN: ${user.gstNumber}", color = NeutralGray400, fontSize = 11.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Role Portal Quick Launcher
        if (user?.role == UserRole.ADMIN) {
            Button(
                onClick = onNavigateToAdmin,
                colors = ButtonDefaults.buttonColors(containerColor = FireRed),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
            ) {
                Icon(Icons.Default.AdminPanelSettings, contentDescription = null, tint = NeutralWhite)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Open OPRONIX Admin Dashboard", fontWeight = FontWeight.Bold, color = NeutralWhite)
            }
            Spacer(modifier = Modifier.height(10.dp))
        }

        if (user?.role == UserRole.TECHNICIAN) {
            Button(
                onClick = onNavigateToTechnician,
                colors = ButtonDefaults.buttonColors(containerColor = SafetyOrange),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
            ) {
                Icon(Icons.Default.Handyman, contentDescription = null, tint = CharcoalBlack)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Open Field Technician Portal", fontWeight = FontWeight.Bold, color = CharcoalBlack)
            }
            Spacer(modifier = Modifier.height(10.dp))
        }

        // Navigation Sections
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = CharcoalCard),
            border = androidx.compose.foundation.BorderStroke(1.dp, CharcoalBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column {
                ProfileMenuRow("Switch Account Role (Demo)", Icons.Default.SwitchAccount, onClick = onSwitchRoleClick)
                HorizontalDivider(color = CharcoalBorder.copy(alpha = 0.5f))
                ProfileMenuRow("My Orders & Invoices", Icons.AutoMirrored.Filled.ReceiptLong, onClick = onNavigateToOrders)
                HorizontalDivider(color = CharcoalBorder.copy(alpha = 0.5f))
                ProfileMenuRow("Service Bookings & Refilling", Icons.Default.Build, onClick = onNavigateToServices)
                HorizontalDivider(color = CharcoalBorder.copy(alpha = 0.5f))
                ProfileMenuRow("Official Quotations", Icons.Default.RequestQuote, onClick = onNavigateToQuotations)
                HorizontalDivider(color = CharcoalBorder.copy(alpha = 0.5f))
                ProfileMenuRow("AMC Annual Contracts", Icons.Default.Handshake, onClick = onNavigateToAmc)
                HorizontalDivider(color = CharcoalBorder.copy(alpha = 0.5f))
                ProfileMenuRow("Notification Updates", Icons.Default.Notifications, onClick = onNavigateToNotifications)
                HorizontalDivider(color = CharcoalBorder.copy(alpha = 0.5f))
                ProfileMenuRow("Contact & Support Desk", Icons.Default.SupportAgent, onClick = onNavigateToContact)
                HorizontalDivider(color = CharcoalBorder.copy(alpha = 0.5f))
                ProfileMenuRow("National Fire Emergency (101 / 112)", Icons.Default.Warning, iconColor = FireRedLight, onClick = onEmergencyClick)
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Sign Out
        OutlinedButton(
            onClick = onLogout,
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = FireRedLight),
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("Sign Out")
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "OPRONIX Android Client v1.0 • Built with Jetpack Compose & Material 3",
            color = NeutralGray400,
            fontSize = 10.sp,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
    }

    if (showEditProfileDialog) {
        EditProfileDialog(
            user = user,
            onDismiss = { showEditProfileDialog = false },
            onSave = { n, p, c, g ->
                onUpdateProfile(n, p, c, g)
                showEditProfileDialog = false
            }
        )
    }
}

@Composable
fun ProfileMenuRow(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconColor: Color = SafetyOrangeLight,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(imageVector = icon, contentDescription = null, tint = iconColor, modifier = Modifier.size(20.dp))
        Spacer(modifier = Modifier.width(14.dp))
        Text(text = title, color = NeutralWhite, fontSize = 13.sp, modifier = Modifier.weight(1f))
        Icon(Icons.Default.ChevronRight, contentDescription = null, tint = NeutralGray400, modifier = Modifier.size(18.dp))
    }
}

@Composable
fun EditProfileDialog(
    user: User?,
    onDismiss: () -> Unit,
    onSave: (name: String, phone: String, company: String, gst: String) -> Unit
) {
    var name by remember { mutableStateOf(user?.name ?: "") }
    var phone by remember { mutableStateOf(user?.phone ?: "") }
    var company by remember { mutableStateOf(user?.companyName ?: "") }
    var gst by remember { mutableStateOf(user?.gstNumber ?: "") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = CharcoalBlack,
            border = androidx.compose.foundation.BorderStroke(1.dp, CharcoalBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("Edit Profile Details", color = NeutralWhite, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Full Name") },
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = NeutralWhite, unfocusedTextColor = NeutralWhite),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Phone") },
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = NeutralWhite, unfocusedTextColor = NeutralWhite),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = company,
                    onValueChange = { company = it },
                    label = { Text("Company Name") },
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = NeutralWhite, unfocusedTextColor = NeutralWhite),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = gst,
                    onValueChange = { gst = it },
                    label = { Text("GSTIN Number") },
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = NeutralWhite, unfocusedTextColor = NeutralWhite),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(16.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel", color = NeutralGray400)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = { onSave(name, phone, company, gst) },
                        colors = ButtonDefaults.buttonColors(containerColor = FireRed)
                    ) {
                        Text("Save Changes", color = NeutralWhite)
                    }
                }
            }
        }
    }
}

@Composable
fun ContactSupportScreen(
    companyInfo: CompanyInfo,
    onBackClick: () -> Unit
) {
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CharcoalBlack)
    ) {
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBackClick) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = NeutralWhite)
                }
                Text(
                    text = "Contact OPRONIX Desk",
                    color = NeutralWhite,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Emergency Notice Banner
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = FireRedDark.copy(alpha = 0.3f)),
                border = androidx.compose.foundation.BorderStroke(1.dp, FireRed),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "EMERGENCY NOTICE (Active Fires):",
                        color = FireRedLight,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = companyInfo.emergencyDisclaimer,
                        color = NeutralWhite,
                        fontSize = 11.sp,
                        lineHeight = 16.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Commercial Contact Cards
            ContactActionCard(
                title = "Call Customer Helpline",
                value = companyInfo.primaryHelpline,
                subtitle = "Available ${companyInfo.workingHours}",
                icon = Icons.Default.Call,
                buttonText = "Call Now",
                onClick = {
                    val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${companyInfo.primaryHelpline.replace(" ", "")}"))
                    context.startActivity(intent)
                }
            )

            Spacer(modifier = Modifier.height(10.dp))

            ContactActionCard(
                title = "WhatsApp Business Desk",
                value = "+91 98290 88888",
                subtitle = "Instant inquiries for refilling, audits & catalog",
                icon = Icons.AutoMirrored.Filled.Chat,
                buttonText = "Open WhatsApp",
                onClick = {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/${companyInfo.whatsAppNumber}"))
                    context.startActivity(intent)
                }
            )

            Spacer(modifier = Modifier.height(10.dp))

            ContactActionCard(
                title = "Official Email Desk",
                value = companyInfo.supportEmail,
                subtitle = "Corporate proposals & tenders: ${companyInfo.salesEmail}",
                icon = Icons.Default.Email,
                buttonText = "Send Email",
                onClick = {
                    val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:${companyInfo.supportEmail}"))
                    context.startActivity(intent)
                }
            )

            Spacer(modifier = Modifier.height(10.dp))

            ContactActionCard(
                title = "Corporate Headquarters & Depot",
                value = companyInfo.headOfficeAddress,
                subtitle = "CIN: ${companyInfo.registrationNumber} • GST: ${companyInfo.gstNumber}",
                icon = Icons.Default.LocationOn,
                buttonText = "Open Map",
                onClick = {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=Sitapura+Industrial+Area+Jaipur+Rajasthan"))
                    context.startActivity(intent)
                }
            )

            Spacer(modifier = Modifier.height(16.dp))

            Text("Active Service Hubs Across India", color = NeutralWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = companyInfo.activeServiceHubs.joinToString(" • "),
                color = SafetyOrangeLight,
                fontSize = 12.sp,
                lineHeight = 18.sp
            )
        }
    }
}

@Composable
fun ContactActionCard(
    title: String,
    value: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    buttonText: String,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = CharcoalCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, CharcoalBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(CharcoalElevated),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, contentDescription = null, tint = SafetyOrangeLight, modifier = Modifier.size(18.dp))
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(title, color = NeutralWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text(value, color = SafetyOrangeLight, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(subtitle, color = NeutralGray400, fontSize = 11.sp)
            Spacer(modifier = Modifier.height(10.dp))
            OutlinedButton(
                onClick = onClick,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(buttonText, color = NeutralWhite, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun NotificationsScreen(
    notifications: List<NotificationItem>,
    onMarkAsRead: (String) -> Unit,
    onBackClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CharcoalBlack)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBackClick) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = NeutralWhite)
            }
            Text(
                text = "Notifications Inbox",
                color = NeutralWhite,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        if (notifications.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.NotificationsNone, contentDescription = null, tint = NeutralGray400, modifier = Modifier.size(48.dp))
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("No notifications yet", color = NeutralWhite, fontWeight = FontWeight.Bold)
                }
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(notifications, key = { it.id }) { item ->
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = if (item.isRead) CharcoalCard else CharcoalElevated),
                        border = androidx.compose.foundation.BorderStroke(1.dp, CharcoalBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onMarkAsRead(item.id) }
                    ) {
                        Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.Top) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(
                                        when (item.type) {
                                            NotificationType.ORDER -> FireRed
                                            NotificationType.SERVICE -> SafetyOrange
                                            NotificationType.QUOTATION -> StatusBlue
                                            NotificationType.AMC_RENEWAL -> StatusGreen
                                            NotificationType.ANNOUNCEMENT -> CharcoalBorder
                                        }
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = when (item.type) {
                                        NotificationType.ORDER -> Icons.AutoMirrored.Filled.ReceiptLong
                                        NotificationType.SERVICE -> Icons.Default.Build
                                        NotificationType.QUOTATION -> Icons.Default.RequestQuote
                                        NotificationType.AMC_RENEWAL -> Icons.Default.Handshake
                                        NotificationType.ANNOUNCEMENT -> Icons.Default.Campaign
                                    },
                                    contentDescription = null,
                                    tint = NeutralWhite,
                                    modifier = Modifier.size(18.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(item.title, color = NeutralWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(item.message, color = NeutralGray200, fontSize = 12.sp, lineHeight = 16.sp)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(item.timestampMillis)),
                                    color = NeutralGray400,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
