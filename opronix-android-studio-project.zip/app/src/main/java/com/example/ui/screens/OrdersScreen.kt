package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Order
import com.example.model.OrderStatus
import com.example.ui.components.InvoiceDialog
import com.example.ui.components.OrderCard
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun OrdersScreen(
    orders: List<Order>,
    onViewOrderDetails: (String) -> Unit
) {
    var selectedOrderForInvoice by remember { mutableStateOf<Order?>(null) }
    var statusFilter by remember { mutableStateOf<OrderStatus?>(null) }

    val filteredOrders = remember(orders, statusFilter) {
        if (statusFilter == null) orders else orders.filter { it.status == statusFilter }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CharcoalBlack)
            .padding(16.dp)
    ) {
        Text(
            text = "My Equipment Orders",
            color = NeutralWhite,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "Track dispatch status and download tax invoices",
            color = NeutralGray400,
            fontSize = 12.sp
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Status Filter Chips
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = statusFilter == null,
                onClick = { statusFilter = null },
                label = { Text("All (${orders.size})") },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = FireRed,
                    selectedLabelColor = NeutralWhite,
                    containerColor = CharcoalCard,
                    labelColor = NeutralGray400
                )
            )

            FilterChip(
                selected = statusFilter == OrderStatus.PROCESSING,
                onClick = { statusFilter = if (statusFilter == OrderStatus.PROCESSING) null else OrderStatus.PROCESSING },
                label = { Text("Processing") },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = FireRed,
                    selectedLabelColor = NeutralWhite,
                    containerColor = CharcoalCard,
                    labelColor = NeutralGray400
                )
            )

            FilterChip(
                selected = statusFilter == OrderStatus.DELIVERED,
                onClick = { statusFilter = if (statusFilter == OrderStatus.DELIVERED) null else OrderStatus.DELIVERED },
                label = { Text("Delivered") },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = FireRed,
                    selectedLabelColor = NeutralWhite,
                    containerColor = CharcoalCard,
                    labelColor = NeutralGray400
                )
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        if (filteredOrders.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ReceiptLong,
                        contentDescription = null,
                        tint = NeutralGray400,
                        modifier = Modifier.size(54.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("No orders in this category", color = NeutralWhite, fontWeight = FontWeight.Bold)
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filteredOrders, key = { it.id }) { order ->
                    OrderCard(
                        order = order,
                        onViewDetails = { onViewOrderDetails(order.id) },
                        onViewInvoice = { selectedOrderForInvoice = order }
                    )
                }
            }
        }
    }

    selectedOrderForInvoice?.let { order ->
        InvoiceDialog(order = order, onDismiss = { selectedOrderForInvoice = null })
    }
}

@Composable
fun OrderDetailScreen(
    order: Order,
    onCancelOrder: (String) -> Unit,
    onBackClick: () -> Unit
) {
    var showInvoiceDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CharcoalBlack)
    ) {
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBackClick) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = NeutralWhite)
                }
                Text(
                    text = "Order Details #${order.id}",
                    color = NeutralWhite,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Order Status Tracker
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = CharcoalCard),
                border = androidx.compose.foundation.BorderStroke(1.dp, CharcoalBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Current Status: ${order.status.displayName}",
                        color = FireRedLight,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                    Text(
                        text = "Placed on ${SimpleDateFormat("dd MMMM yyyy, hh:mm a", Locale.getDefault()).format(Date(order.orderDateMillis))}",
                        color = NeutralGray400,
                        fontSize = 11.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Tracking Timeline
                    val statuses = listOf(
                        OrderStatus.PENDING to "Order Received",
                        OrderStatus.CONFIRMED to "Confirmed",
                        OrderStatus.PROCESSING to "Dispatched from Hub",
                        OrderStatus.DELIVERED to "Delivered & Inspected"
                    )

                    val currentIndex = when (order.status) {
                        OrderStatus.PENDING -> 0
                        OrderStatus.CONFIRMED -> 1
                        OrderStatus.PROCESSING, OrderStatus.SHIPPED -> 2
                        OrderStatus.DELIVERED -> 3
                        OrderStatus.CANCELLED -> -1
                    }

                    statuses.forEachIndexed { index, (st, label) ->
                        val isDone = currentIndex >= index
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(vertical = 4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(24.dp)
                                    .clip(CircleShape)
                                    .background(if (isDone) FireRed else CharcoalElevated),
                                contentAlignment = Alignment.Center
                            ) {
                                if (isDone) {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = NeutralWhite, modifier = Modifier.size(14.dp))
                                }
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = label,
                                color = if (isDone) NeutralWhite else NeutralGray400,
                                fontWeight = if (isDone) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Items Purchased
            Text(
                text = "Equipment List (${order.items.size} products)",
                color = NeutralWhite,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))

            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = CharcoalCard),
                border = androidx.compose.foundation.BorderStroke(1.dp, CharcoalBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    order.items.forEach { item ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = item.product.name,
                                    color = NeutralWhite,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "${item.quantity} units x ${item.product.formattedPrice}",
                                    color = NeutralGray400,
                                    fontSize = 11.sp
                                )
                            }
                            Text(
                                text = item.formattedItemPrice,
                                color = FireRedLight,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                        HorizontalDivider(color = CharcoalBorder.copy(alpha = 0.5f))
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Delivery Details
            Text(
                text = "Delivery & Billing Details",
                color = NeutralWhite,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))

            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = CharcoalCard),
                border = androidx.compose.foundation.BorderStroke(1.dp, CharcoalBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(text = "Invoice Number: ${order.invoiceNumber}", color = SafetyOrangeLight, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = "Customer: ${order.customerName}", color = NeutralWhite, fontSize = 12.sp)
                    Text(text = "Address: ${order.deliveryAddress.formatted}", color = NeutralGray200, fontSize = 12.sp)
                    Text(text = "Payment Mode: ${order.paymentMethod.displayName}", color = NeutralGray400, fontSize = 12.sp)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Actions: View Invoice
            Button(
                onClick = { showInvoiceDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = CharcoalElevated),
                border = androidx.compose.foundation.BorderStroke(1.dp, SafetyOrange),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Receipt, contentDescription = null, tint = SafetyOrangeLight)
                Spacer(modifier = Modifier.width(8.dp))
                Text("View Full GST Tax Invoice", color = SafetyOrangeLight, fontWeight = FontWeight.Bold)
            }

            if (order.status == OrderStatus.PENDING) {
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedButton(
                    onClick = { onCancelOrder(order.id) },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = FireRedLight),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Cancel Order")
                }
            }
        }
    }

    if (showInvoiceDialog) {
        InvoiceDialog(order = order, onDismiss = { showInvoiceDialog = false })
    }
}
