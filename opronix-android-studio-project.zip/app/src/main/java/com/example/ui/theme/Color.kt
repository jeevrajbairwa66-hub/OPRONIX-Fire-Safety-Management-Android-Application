package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// OPRONIX Brand Primary & Secondary Colors
val FireRed = Color(0xFFE53935)
val FireRedDark = Color(0xFFB71C1C)
val FireRedLight = Color(0xFFFF5252)

val SafetyOrange = Color(0xFFFF8A00)
val SafetyOrangeLight = Color(0xFFFFA726)
val SafetyOrangeDark = Color(0xFFE65100)

val CharcoalBlack = Color(0xFF101820)
val CharcoalCard = Color(0xFF1A232E)
val CharcoalElevated = Color(0xFF232F3D)
val CharcoalBorder = Color(0xFF324153)

// Neutrals
val NeutralWhite = Color(0xFFFFFFFF)
val NeutralOffWhite = Color(0xFFF8F9FB)
val NeutralGray50 = Color(0xFFF1F3F5)
val NeutralGray200 = Color(0xFFE2E6EA)
val NeutralGray400 = Color(0xFF9AA0A6)
val NeutralGray600 = Color(0xFF5F6368)
val NeutralGray800 = Color(0xFF202124)

// Functional colors
val StatusGreen = Color(0xFF2E7D32)
val StatusGreenBg = Color(0xFFE8F5E9)
val StatusAmber = Color(0xFFF57C00)
val StatusAmberBg = Color(0xFFFFF3E0)
val StatusBlue = Color(0xFF1976D2)
val StatusBlueBg = Color(0xFFE3F2FD)
val StatusRedBg = Color(0xFFFFEBEE)
