package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = FireRedLight,
    onPrimary = CharcoalBlack,
    primaryContainer = FireRedDark,
    onPrimaryContainer = NeutralWhite,
    secondary = SafetyOrangeLight,
    onSecondary = CharcoalBlack,
    secondaryContainer = SafetyOrangeDark,
    onSecondaryContainer = NeutralWhite,
    tertiary = SafetyOrange,
    background = CharcoalBlack,
    onBackground = NeutralWhite,
    surface = CharcoalCard,
    onSurface = NeutralWhite,
    surfaceVariant = CharcoalElevated,
    onSurfaceVariant = NeutralGray400,
    outline = CharcoalBorder
)

private val LightColorScheme = lightColorScheme(
    primary = FireRed,
    onPrimary = NeutralWhite,
    primaryContainer = StatusRedBg,
    onPrimaryContainer = FireRedDark,
    secondary = SafetyOrange,
    onSecondary = NeutralWhite,
    secondaryContainer = StatusAmberBg,
    onSecondaryContainer = SafetyOrangeDark,
    tertiary = CharcoalBlack,
    background = NeutralOffWhite,
    onBackground = CharcoalBlack,
    surface = NeutralWhite,
    onSurface = CharcoalBlack,
    surfaceVariant = NeutralGray50,
    onSurfaceVariant = NeutralGray600,
    outline = NeutralGray200
)

@Composable
fun OpronixTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
