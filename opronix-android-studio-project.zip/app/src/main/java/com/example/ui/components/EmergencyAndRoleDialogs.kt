package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.Order
import com.example.model.UserRole
import com.example.ui.theme.*

@Composable
fun EmergencyDialog(
    onDismiss: () -> Unit
) {
    val context = LocalContext.current

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = CharcoalBlack,
            border = androidx.compose.foundation.BorderStroke(1.5.dp, FireRed),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(FireRed),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = "Emergency Alert",
                        tint = NeutralWhite,
                        modifier = Modifier.size(32.dp)
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "EMERGENCY SAFETY NOTICE",
                    color = FireRedLight,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "If you are facing an active fire, smoke, or life-safety emergency, please contact government emergency services immediately. OPRONIX does not dispatch first responders.",
                    color = NeutralGray200,
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )

                Spacer(modifier = Modifier.height(18.dp))

                // 101 Fire Emergency Button
                Button(
                    onClick = {
                        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:101"))
                        context.startActivity(intent)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = FireRed),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("dial_101_button")
                ) {
                    Icon(Icons.Default.Call, contentDescription = null, tint = NeutralWhite)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Dial 101 (Fire Brigade - India)", fontWeight = FontWeight.Bold, color = NeutralWhite)
                }

                Spacer(modifier = Modifier.height(10.dp))

                // 112 National Emergency Button
                Button(
                    onClick = {
                        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:112"))
                        context.startActivity(intent)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CharcoalElevated),
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CharcoalBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("dial_112_button")
                ) {
                    Icon(Icons.Default.PhoneInTalk, contentDescription = null, tint = SafetyOrangeLight)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Dial 112 (National Emergency)", fontWeight = FontWeight.SemiBold, color = NeutralWhite)
                }

                Spacer(modifier = Modifier.height(10.dp))

                // OPRONIX Commercial Helpline Button
                OutlinedButton(
                    onClick = {
                        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:+919829088888"))
                        context.startActivity(intent)
                    },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.SupportAgent, contentDescription = null, tint = NeutralWhite)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Call OPRONIX Desk (+91 98290 88888)", color = NeutralWhite)
                }

                Spacer(modifier = Modifier.height(14.dp))

                TextButton(onClick = onDismiss) {
                    Text("Close Notice", color = NeutralGray400)
                }
            }
        }
    }
}

@Composable
fun RoleSwitcherDialog(
    currentRole: UserRole,
    onRoleSelected: (UserRole) -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = CharcoalBlack,
            border = androidx.compose.foundation.BorderStroke(1.dp, CharcoalBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "Demo Role Switcher",
                    color = NeutralWhite,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Select a perspective to test role-based access & views:",
                    color = NeutralGray400,
                    fontSize = 12.sp
                )

                Spacer(modifier = Modifier.height(16.dp))

                RoleOptionCard(
                    title = "Customer Profile",
                    subtitle = "Rajesh Sharma (Sharma Enterprises) - Browse, Order, AMC, Bookings",
                    icon = Icons.Default.Person,
                    isSelected = currentRole == UserRole.CUSTOMER,
                    onClick = {
                        onRoleSelected(UserRole.CUSTOMER)
                        onDismiss()
                    }
                )

                Spacer(modifier = Modifier.height(10.dp))

                RoleOptionCard(
                    title = "Field Technician",
                    subtitle = "Vikram Singh - View assigned jobs, site info, update service status",
                    icon = Icons.Default.Handyman,
                    isSelected = currentRole == UserRole.TECHNICIAN,
                    onClick = {
                        onRoleSelected(UserRole.TECHNICIAN)
                        onDismiss()
                    }
                )

                Spacer(modifier = Modifier.height(10.dp))

                RoleOptionCard(
                    title = "Company Administrator",
                    subtitle = "OPRONIX Admin - Manage inventory, orders, technician assignment, quotes",
                    icon = Icons.Default.AdminPanelSettings,
                    isSelected = currentRole == UserRole.ADMIN,
                    onClick = {
                        onRoleSelected(UserRole.ADMIN)
                        onDismiss()
                    }
                )

                Spacer(modifier = Modifier.height(14.dp))

                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Text("Cancel", color = NeutralGray400)
                }
            }
        }
    }
}

@Composable
private fun RoleOptionCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = if (isSelected) FireRed.copy(alpha = 0.15f) else CharcoalCard,
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isSelected) FireRed else CharcoalBorder
        ),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (isSelected) FireRed else CharcoalElevated),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (isSelected) NeutralWhite else SafetyOrangeLight,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    color = NeutralWhite,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Text(
                    text = subtitle,
                    color = NeutralGray400,
                    fontSize = 11.sp,
                    lineHeight = 15.sp
                )
            }

            if (isSelected) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = "Selected",
                    tint = FireRedLight,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
fun InvoiceDialog(
    order: Order,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = NeutralWhite,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "OPRONIX",
                            color = FireRed,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = "Tax Invoice / Bill of Supply",
                            color = NeutralGray600,
                            fontSize = 11.sp
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = StatusGreenBg
                    ) {
                        Text(
                            text = order.paymentStatus.name,
                            color = StatusGreen,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = NeutralGray200)

                Text(
                    text = "Invoice No: ${order.invoiceNumber}",
                    fontWeight = FontWeight.Bold,
                    color = CharcoalBlack,
                    fontSize = 13.sp
                )
                Text(text = "Order ID: ${order.id}", color = NeutralGray600, fontSize = 12.sp)
                Text(text = "Customer: ${order.customerName}", color = CharcoalBlack, fontSize = 12.sp)
                Text(text = "Phone: ${order.customerPhone}", color = NeutralGray600, fontSize = 12.sp)
                Text(text = "Delivery: ${order.deliveryAddress.formatted}", color = NeutralGray600, fontSize = 12.sp)

                HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = NeutralGray200)

                Text(
                    text = "Itemized Breakdown",
                    fontWeight = FontWeight.Bold,
                    color = CharcoalBlack,
                    fontSize = 13.sp
                )

                Spacer(modifier = Modifier.height(8.dp))

                order.items.forEach { item ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "${item.quantity}x ${item.product.name}",
                            fontSize = 12.sp,
                            color = CharcoalBlack,
                            modifier = Modifier.weight(1f)
                        )
                        Text(
                            text = item.formattedItemPrice,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = CharcoalBlack
                        )
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = NeutralGray200)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Subtotal", color = NeutralGray600, fontSize = 12.sp)
                    Text("₹%,.0f".format(order.subtotal), color = CharcoalBlack, fontSize = 12.sp)
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("GST (18%)", color = NeutralGray600, fontSize = 12.sp)
                    Text("₹%,.0f".format(order.gstAmount), color = CharcoalBlack, fontSize = 12.sp)
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Delivery & Handling", color = NeutralGray600, fontSize = 12.sp)
                    Text("₹%,.0f".format(order.deliveryFee), color = CharcoalBlack, fontSize = 12.sp)
                }
                if (order.discount > 0) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Promotional Discount", color = StatusGreen, fontSize = 12.sp)
                        Text("-₹%,.0f".format(order.discount), color = StatusGreen, fontSize = 12.sp)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Grand Total (INR)", fontWeight = FontWeight.Bold, color = CharcoalBlack, fontSize = 14.sp)
                    Text(order.formattedTotal, fontWeight = FontWeight.Bold, color = FireRed, fontSize = 15.sp)
                }

                Spacer(modifier = Modifier.height(20.dp))

                Row(modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Close")
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Button(
                        onClick = {
                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(
                                    Intent.EXTRA_TEXT,
                                    "OPRONIX Fire Safety Solutions - Invoice #${order.invoiceNumber}\n" +
                                            "Order ID: ${order.id}\n" +
                                            "Total Amount: ${order.formattedTotal}\n" +
                                            "Date: ${SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date(order.orderDateMillis))}"
                                )
                            }
                            context.startActivity(Intent.createChooser(shareIntent, "Share Invoice Summary"))
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = FireRed),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Share")
                    }
                }
            }
        }
    }
}
