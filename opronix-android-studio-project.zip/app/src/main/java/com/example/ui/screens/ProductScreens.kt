package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.components.ProductCard
import com.example.ui.theme.*

@Composable
fun ProductListScreen(
    products: List<Product>,
    selectedCategory: ProductCategory?,
    onCategorySelected: (ProductCategory?) -> Unit,
    onProductClick: (String) -> Unit,
    onAddToCart: (Product) -> Unit,
    onToggleFavorite: (String) -> Unit,
    onOpenCart: () -> Unit,
    cartItemCount: Int
) {
    var searchQuery by remember { mutableStateOf("") }
    var showOnlyFavorites by remember { mutableStateOf(false) }
    var sortByPriceAsc by remember { mutableStateOf<Boolean?>(null) }

    val filteredProducts = remember(products, selectedCategory, searchQuery, showOnlyFavorites, sortByPriceAsc) {
        var list = products
        if (selectedCategory != null) {
            list = list.filter { it.category == selectedCategory }
        }
        if (showOnlyFavorites) {
            list = list.filter { it.isFavorite }
        }
        if (searchQuery.isNotBlank()) {
            list = list.filter {
                it.name.contains(searchQuery, ignoreCase = true) ||
                        it.description.contains(searchQuery, ignoreCase = true) ||
                        it.capacity.contains(searchQuery, ignoreCase = true)
            }
        }
        when (sortByPriceAsc) {
            true -> list.sortedBy { it.price }
            false -> list.sortedByDescending { it.price }
            null -> list
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CharcoalBlack)
    ) {
        // Search & Filter Header
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(CharcoalCard)
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search 15 product lines...", color = NeutralGray400, fontSize = 13.sp) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = SafetyOrangeLight) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear", tint = NeutralGray400)
                            }
                        }
                    },
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = FireRed,
                        unfocusedBorderColor = CharcoalBorder,
                        focusedTextColor = NeutralWhite,
                        unfocusedTextColor = NeutralWhite
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("product_search_input")
                )

                Spacer(modifier = Modifier.width(8.dp))

                // Cart quick shortcut
                IconButton(
                    onClick = onOpenCart,
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(FireRed)
                        .testTag("cart_icon_button")
                ) {
                    BadgedBox(badge = {
                        if (cartItemCount > 0) {
                            Badge(containerColor = SafetyOrange) {
                                Text("$cartItemCount", color = CharcoalBlack, fontWeight = FontWeight.Bold)
                            }
                        }
                    }) {
                        Icon(Icons.Default.ShoppingCart, contentDescription = "Cart", tint = NeutralWhite)
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Category Filter Pills
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                item {
                    FilterChip(
                        selected = selectedCategory == null && !showOnlyFavorites,
                        onClick = {
                            onCategorySelected(null)
                            showOnlyFavorites = false
                        },
                        label = { Text("All Products (${products.size})") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = FireRed,
                            selectedLabelColor = NeutralWhite,
                            containerColor = CharcoalElevated,
                            labelColor = NeutralGray400
                        )
                    )
                }

                item {
                    FilterChip(
                        selected = showOnlyFavorites,
                        onClick = { showOnlyFavorites = !showOnlyFavorites },
                        label = { Text("★ Saved") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = SafetyOrange,
                            selectedLabelColor = CharcoalBlack,
                            containerColor = CharcoalElevated,
                            labelColor = NeutralGray400
                        )
                    )
                }

                items(ProductCategory.values()) { category ->
                    FilterChip(
                        selected = selectedCategory == category,
                        onClick = {
                            onCategorySelected(if (selectedCategory == category) null else category)
                        },
                        label = { Text(category.displayName) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = FireRed,
                            selectedLabelColor = NeutralWhite,
                            containerColor = CharcoalElevated,
                            labelColor = NeutralGray400
                        )
                    )
                }
            }

            // Sort bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${filteredProducts.size} safety items available",
                    color = NeutralGray400,
                    fontSize = 11.sp
                )

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "Sort: ",
                        color = NeutralGray400,
                        fontSize = 11.sp
                    )
                    Text(
                        text = when (sortByPriceAsc) {
                            true -> "Price ↑"
                            false -> "Price ↓"
                            null -> "Default"
                        },
                        color = SafetyOrangeLight,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable {
                            sortByPriceAsc = when (sortByPriceAsc) {
                                null -> true
                                true -> false
                                false -> null
                            }
                        }
                    )
                }
            }
        }

        // Product Grid
        if (filteredProducts.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.SearchOff,
                        contentDescription = null,
                        tint = NeutralGray400,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("No products found", color = NeutralWhite, fontWeight = FontWeight.Bold)
                    Text("Try resetting filters or search query", color = NeutralGray400, fontSize = 12.sp)
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filteredProducts, key = { it.id }) { product ->
                    ProductCard(
                        product = product,
                        onProductClick = { onProductClick(product.id) },
                        onAddToCart = { onAddToCart(product) },
                        onToggleFavorite = { onToggleFavorite(product.id) }
                    )
                }
            }
        }
    }
}

@Composable
fun ProductDetailScreen(
    product: Product,
    onAddToCart: (Product, Int) -> Unit,
    onBuyNow: (Product, Int) -> Unit,
    onRequestQuotation: (Product) -> Unit,
    onToggleFavorite: (String) -> Unit,
    onBackClick: () -> Unit
) {
    var quantity by remember { mutableStateOf(1) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CharcoalBlack)
    ) {
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            // Header / Category & favorite
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBackClick) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = NeutralWhite)
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = FireRed.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = product.category.displayName,
                        color = FireRedLight,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                IconButton(onClick = { onToggleFavorite(product.id) }) {
                    Icon(
                        imageVector = if (product.isFavorite) Icons.Default.Favorite else Icons.Outlined.FavoriteBorder,
                        contentDescription = "Favorite",
                        tint = if (product.isFavorite) FireRed else NeutralGray400
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Large Hero Image Area
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Brush.radialGradient(listOf(CharcoalElevated, CharcoalBlack)))
                    .border(1.dp, CharcoalBorder, RoundedCornerShape(16.dp)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        modifier = Modifier
                            .size(76.dp)
                            .clip(CircleShape)
                            .background(Brush.linearGradient(listOf(FireRed, SafetyOrange))),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocalFireDepartment,
                            contentDescription = product.name,
                            tint = NeutralWhite,
                            modifier = Modifier.size(42.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = product.standardCompliance,
                        color = NeutralWhite,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }

                // Demo Notice
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = CharcoalBlack.copy(alpha = 0.85f),
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(10.dp)
                ) {
                    Text(
                        text = "DEMO SPECIFICATIONS",
                        color = SafetyOrangeLight,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Product Name & Hindi Name
            Text(
                text = product.name,
                color = NeutralWhite,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )

            if (product.hindiName.isNotBlank()) {
                Text(
                    text = product.hindiName,
                    color = SafetyOrangeLight,
                    fontSize = 13.sp
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Price & Capacity
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = product.formattedPrice,
                            color = FireRedLight,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        product.formattedOriginalPrice?.let { orig ->
                            Text(
                                text = orig,
                                color = NeutralGray400,
                                fontSize = 14.sp,
                                textDecoration = TextDecoration.LineThrough
                            )
                        }
                    }
                    Text(text = "Excl. 18% GST (Calculated at checkout)", color = NeutralGray400, fontSize = 11.sp)
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = StatusGreenBg
                ) {
                    Text(
                        text = "In Stock (${product.stockQuantity} units)",
                        color = StatusGreen,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Description
            Text(
                text = "Description",
                color = NeutralWhite,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = product.description,
                color = NeutralGray200,
                fontSize = 13.sp,
                lineHeight = 19.sp
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Technical Specifications Table
            if (product.specifications.isNotEmpty()) {
                Text(
                    text = "Technical Specifications",
                    color = NeutralWhite,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))

                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = CharcoalCard),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CharcoalBorder)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        product.specifications.forEach { (key, value) ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(text = key, color = NeutralGray400, fontSize = 12.sp)
                                Text(
                                    text = value,
                                    color = NeutralWhite,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                            HorizontalDivider(color = CharcoalBorder.copy(alpha = 0.5f))
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Warranty Notice
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CharcoalElevated, RoundedCornerShape(10.dp))
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Verified, contentDescription = null, tint = StatusGreen, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = product.warrantyText,
                    color = NeutralWhite,
                    fontSize = 12.sp
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Request Bulk Quotation Button
            OutlinedButton(
                onClick = { onRequestQuotation(product) },
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.RequestQuote, contentDescription = null, tint = SafetyOrangeLight)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Request Bulk Commercial Quotation", color = SafetyOrangeLight, fontWeight = FontWeight.Bold)
            }
        }

        // Bottom Purchase Controls
        Surface(
            color = CharcoalCard,
            tonalElevation = 8.dp,
            border = androidx.compose.foundation.BorderStroke(1.dp, CharcoalBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .padding(16.dp)
                    .navigationBarsPadding(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Quantity Selector
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .background(CharcoalElevated, RoundedCornerShape(8.dp))
                        .padding(horizontal = 4.dp)
                ) {
                    IconButton(
                        onClick = { if (quantity > 1) quantity-- },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Text("-", color = NeutralWhite, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                    Text(
                        text = "$quantity",
                        color = NeutralWhite,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        modifier = Modifier.padding(horizontal = 8.dp)
                    )
                    IconButton(
                        onClick = { quantity++ },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Text("+", color = NeutralWhite, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                // Add to Cart
                OutlinedButton(
                    onClick = { onAddToCart(product, quantity) },
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Add to Cart", color = NeutralWhite, fontSize = 12.sp)
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Buy Now
                Button(
                    onClick = { onBuyNow(product, quantity) },
                    colors = ButtonDefaults.buttonColors(containerColor = FireRed),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Buy Now", fontWeight = FontWeight.Bold, color = NeutralWhite, fontSize = 12.sp)
                }
            }
        }
    }
}
