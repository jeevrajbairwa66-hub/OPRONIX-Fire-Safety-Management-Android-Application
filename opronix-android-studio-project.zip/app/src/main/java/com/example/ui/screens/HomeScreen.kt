package com.example.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.*
import com.example.ui.components.ProductCard
import com.example.ui.components.ServiceCard
import com.example.ui.theme.*

@Composable
fun HomeScreen(
    userName: String,
    products: List<Product>,
    onProductClick: (String) -> Unit,
    onAddToCart: (Product) -> Unit,
    onToggleFavorite: (String) -> Unit,
    onNavigateToCategory: (ProductCategory) -> Unit,
    onBookService: (ServiceType) -> Unit,
    onRequestQuotation: () -> Unit,
    onViewAmc: () -> Unit,
    onViewAllProducts: () -> Unit,
    onViewAllServices: () -> Unit,
    onEmergencyClick: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    val featuredProducts = remember(products) { products.filter { it.isFeatured } }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CharcoalBlack)
            .verticalScroll(rememberScrollState())
            .padding(bottom = 24.dp)
    ) {
        // Hero Greeting & Search Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        listOf(CharcoalBlack, Color(0xFF16212D))
                    )
                )
                .padding(16.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Hello, $userName 👋",
                            color = NeutralWhite,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Protecting lives and infrastructure in India",
                            color = NeutralGray400,
                            fontSize = 12.sp
                        )
                    }

                    // Emergency Badge CTA
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = FireRed,
                        modifier = Modifier.clickable { onEmergencyClick() }
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = null,
                                tint = NeutralWhite,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Emergency 101",
                                color = NeutralWhite,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Search Bar
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search extinguishers, alarms, sensors...", color = NeutralGray400, fontSize = 13.sp) },
                    leadingIcon = {
                        Icon(Icons.Default.Search, contentDescription = "Search", tint = SafetyOrangeLight)
                    },
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = CharcoalCard,
                        unfocusedContainerColor = CharcoalCard,
                        focusedBorderColor = FireRed,
                        unfocusedBorderColor = CharcoalBorder,
                        focusedTextColor = NeutralWhite,
                        unfocusedTextColor = NeutralWhite
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("home_search_bar")
                )
            }
        }

        // Promotional Carousel Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(Brush.horizontalGradient(listOf(Color(0xFF8B1214), Color(0xFFC62828))))
                .border(1.dp, CharcoalBorder, RoundedCornerShape(18.dp))
        ) {
            Column {
                Image(
                    painter = painterResource(id = R.drawable.banner_fire_audit),
                    contentDescription = "Fire Safety Engineering",
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp),
                    contentScale = ContentScale.Crop
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(CharcoalCard)
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Turnkey Fire Audits & AMC",
                            color = NeutralWhite,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Commercial compliance under National Building Code (NBC)",
                            color = NeutralGray400,
                            fontSize = 11.sp
                        )
                    }

                    Button(
                        onClick = onRequestQuotation,
                        colors = ButtonDefaults.buttonColors(containerColor = FireRed),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text("Get Quote", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = NeutralWhite)
                    }
                }
            }
        }

        // Quick Actions Grid (4 primary tasks)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            QuickActionItem(
                title = "Refill Service",
                icon = Icons.Default.Refresh,
                modifier = Modifier.weight(1f),
                onClick = { onBookService(ServiceType.EXTINGUISHER_REFILLING) }
            )
            QuickActionItem(
                title = "Book Audit",
                icon = Icons.Default.VerifiedUser,
                modifier = Modifier.weight(1f),
                onClick = { onBookService(ServiceType.FIRE_SAFETY_AUDIT) }
            )
            QuickActionItem(
                title = "AMC Plans",
                icon = Icons.Default.Handshake,
                modifier = Modifier.weight(1f),
                onClick = onViewAmc
            )
            QuickActionItem(
                title = "Bulk Quote",
                icon = Icons.Default.RequestQuote,
                modifier = Modifier.weight(1f),
                onClick = onRequestQuotation
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Categories Section
        SectionHeader(
            title = "Equipment Categories",
            subtitle = "15 IS 15683 certified fire safety ranges",
            onActionClick = onViewAllProducts,
            actionLabel = "View All"
        )

        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(ProductCategory.values().take(7)) { cat ->
                CategoryChipCard(
                    category = cat,
                    onClick = { onNavigateToCategory(cat) }
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Featured Equipment Products
        SectionHeader(
            title = "Featured Fire Extinguishers & Detectors",
            subtitle = "Popular certified safety equipment in India",
            onActionClick = onViewAllProducts,
            actionLabel = "Catalogue"
        )

        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(featuredProducts) { prod ->
                ProductCard(
                    product = prod,
                    onProductClick = { onProductClick(prod.id) },
                    onAddToCart = { onAddToCart(prod) },
                    onToggleFavorite = { onToggleFavorite(prod.id) },
                    modifier = Modifier.width(220.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(22.dp))

        // Popular Services Section
        SectionHeader(
            title = "Safety & Maintenance Services",
            subtitle = "On-site testing, installation and refilling",
            onActionClick = onViewAllServices,
            actionLabel = "All Services"
        )

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            ServiceCard(
                serviceType = ServiceType.EXTINGUISHER_REFILLING,
                onRequestService = { onBookService(ServiceType.EXTINGUISHER_REFILLING) }
            )
            ServiceCard(
                serviceType = ServiceType.ALARM_INSTALLATION,
                onRequestService = { onBookService(ServiceType.ALARM_INSTALLATION) }
            )
            ServiceCard(
                serviceType = ServiceType.FIRE_SAFETY_AUDIT,
                onRequestService = { onBookService(ServiceType.FIRE_SAFETY_AUDIT) }
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Trust & Indian Standards Section
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = CharcoalCard),
            border = androidx.compose.foundation.BorderStroke(1.dp, CharcoalBorder),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = null,
                        tint = SafetyOrangeLight,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Engineering Standards & Verification",
                        color = NeutralWhite,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "• Conforming to Bureau of Indian Standards (BIS / IS 15683)\n" +
                            "• National Building Code of India (NBC 2016 Part 4) Fire & Life Safety\n" +
                            "• Certified Factory Hydrostatic Pressure Testing\n" +
                            "• Official Commercial Tax Invoices with 18% GST Compliance\n" +
                            "• Sample prices and specifications are currently demo data until admin replacement",
                    color = NeutralGray400,
                    fontSize = 12.sp,
                    lineHeight = 18.sp
                )
            }
        }
    }
}

@Composable
fun SectionHeader(
    title: String,
    subtitle: String,
    onActionClick: () -> Unit,
    actionLabel: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                color = NeutralWhite,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = subtitle,
                color = NeutralGray400,
                fontSize = 11.sp
            )
        }

        TextButton(onClick = onActionClick) {
            Text(
                text = actionLabel,
                color = SafetyOrangeLight,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun QuickActionItem(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = CharcoalCard,
        border = androidx.compose.foundation.BorderStroke(1.dp, CharcoalBorder),
        modifier = modifier.clickable { onClick() }
    ) {
        Column(
            modifier = Modifier.padding(vertical = 12.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(CharcoalElevated),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = SafetyOrangeLight,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = title,
                color = NeutralWhite,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun CategoryChipCard(
    category: ProductCategory,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = CharcoalCard,
        border = androidx.compose.foundation.BorderStroke(1.dp, CharcoalBorder),
        modifier = Modifier
            .clickable { onClick() }
            .width(130.dp)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(FireRed.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.LocalFireDepartment,
                    contentDescription = null,
                    tint = FireRedLight,
                    modifier = Modifier.size(18.dp)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = category.displayName,
                color = NeutralWhite,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                maxLines = 2,
                lineHeight = 14.sp
            )

            Spacer(modifier = Modifier.height(2.dp))

            Text(
                text = category.hindiName,
                color = NeutralGray400,
                fontSize = 10.sp,
                textAlign = TextAlign.Center,
                maxLines = 1
            )
        }
    }
}
