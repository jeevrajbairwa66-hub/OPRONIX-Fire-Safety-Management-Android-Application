package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.theme.*

@Composable
fun ProductCard(
    product: Product,
    onProductClick: () -> Unit,
    onAddToCart: () -> Unit,
    onToggleFavorite: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CharcoalCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, CharcoalBorder),
        modifier = modifier
            .fillMaxWidth()
            .clickable { onProductClick() }
            .testTag("product_card_${product.id}")
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            // Header: Category tag & favorite button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = FireRed.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = product.capacity,
                        color = FireRedLight,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }

                IconButton(
                    onClick = onToggleFavorite,
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        imageVector = if (product.isFavorite) Icons.Default.Favorite else Icons.Outlined.FavoriteBorder,
                        contentDescription = "Favorite",
                        tint = if (product.isFavorite) FireRed else NeutralGray400,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Visual Placeholder Box with Category Flame motif
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(110.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Brush.radialGradient(listOf(CharcoalElevated, CharcoalBlack))),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        modifier = Modifier
                            .size(50.dp)
                            .clip(CircleShape)
                            .background(Brush.linearGradient(listOf(FireRed, SafetyOrange))),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = when (product.category) {
                                ProductCategory.ABC_EXTINGUISHER,
                                ProductCategory.CO2_EXTINGUISHER,
                                ProductCategory.FOAM_EXTINGUISHER,
                                ProductCategory.WATER_EXTINGUISHER -> Icons.Default.LocalFireDepartment
                                ProductCategory.SMOKE_DETECTOR,
                                ProductCategory.HEAT_DETECTOR -> Icons.Default.Sensors
                                ProductCategory.ALARM_PANEL -> Icons.Default.Dashboard
                                ProductCategory.ALARM_HOOTER -> Icons.AutoMirrored.Filled.VolumeUp
                                ProductCategory.SPRINKLER_SYSTEM -> Icons.Default.Grain
                                ProductCategory.HOSE_REEL,
                                ProductCategory.HYDRANT_EQUIPMENT -> Icons.Default.WaterDamage
                                ProductCategory.SAFETY_SIGNAGE -> Icons.Default.Warning
                                ProductCategory.EMERGENCY_LIGHT -> Icons.Default.Lightbulb
                                ProductCategory.FIRE_BLANKET -> Icons.Default.Layers
                                ProductCategory.ACCESSORIES -> Icons.Default.Build
                            },
                            contentDescription = product.name,
                            tint = NeutralWhite,
                            modifier = Modifier.size(26.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = product.standardCompliance.take(20),
                        color = NeutralGray400,
                        fontSize = 9.sp
                    )
                }

                // Demo Pill on card
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = CharcoalBlack.copy(alpha = 0.8f),
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(6.dp)
                ) {
                    Text(
                        text = "DEMO SAMPLE",
                        color = SafetyOrangeLight,
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = product.name,
                color = NeutralWhite,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                lineHeight = 17.sp
            )

            Spacer(modifier = Modifier.height(4.dp))

            // Price Row
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = product.formattedPrice,
                    color = FireRedLight,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 15.sp
                )

                product.formattedOriginalPrice?.let { orig ->
                    Text(
                        text = orig,
                        color = NeutralGray400,
                        fontSize = 11.sp,
                        textDecoration = TextDecoration.LineThrough
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Add to Cart Button
            Button(
                onClick = onAddToCart,
                colors = ButtonDefaults.buttonColors(containerColor = FireRed),
                shape = RoundedCornerShape(10.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(36.dp)
                    .testTag("add_to_cart_${product.id}")
            ) {
                Icon(
                    imageVector = Icons.Default.ShoppingCart,
                    contentDescription = null,
                    modifier = Modifier.size(14.dp),
                    tint = NeutralWhite
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Add to Cart",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = NeutralWhite
                )
            }
        }
    }
}

@Composable
fun ServiceCard(
    serviceType: ServiceType,
    onRequestService: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = CharcoalCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, CharcoalBorder),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onRequestService() }
            .testTag("service_card_${serviceType.name}")
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Brush.linearGradient(listOf(SafetyOrange, FireRed))),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Build,
                    contentDescription = null,
                    tint = NeutralWhite,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = serviceType.title,
                    color = NeutralWhite,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Text(
                    text = serviceType.hindiTitle,
                    color = SafetyOrangeLight,
                    fontSize = 11.sp
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Starting from ₹%,.0f • Site Visit".format(serviceType.baseFee),
                    color = NeutralGray400,
                    fontSize = 11.sp
                )
            }

            Button(
                onClick = onRequestService,
                colors = ButtonDefaults.buttonColors(containerColor = CharcoalElevated),
                border = androidx.compose.foundation.BorderStroke(1.dp, SafetyOrange),
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Text(
                    text = "Book",
                    color = SafetyOrangeLight,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun OrderCard(
    order: Order,
    onViewDetails: () -> Unit,
    onViewInvoice: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = CharcoalCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, CharcoalBorder),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onViewDetails() }
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "#${order.id}",
                        color = NeutralWhite,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Text(
                        text = "Inv: ${order.invoiceNumber}",
                        color = NeutralGray400,
                        fontSize = 11.sp
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = when (order.status) {
                        OrderStatus.PENDING -> StatusAmberBg
                        OrderStatus.CONFIRMED, OrderStatus.PROCESSING -> StatusBlueBg
                        OrderStatus.SHIPPED, OrderStatus.DELIVERED -> StatusGreenBg
                        OrderStatus.CANCELLED -> StatusRedBg
                    }
                ) {
                    Text(
                        text = order.status.displayName,
                        color = when (order.status) {
                            OrderStatus.PENDING -> StatusAmber
                            OrderStatus.CONFIRMED, OrderStatus.PROCESSING -> StatusBlue
                            OrderStatus.SHIPPED, OrderStatus.DELIVERED -> StatusGreen
                            OrderStatus.CANCELLED -> FireRed
                        },
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = CharcoalBorder)

            order.items.take(2).forEach { item ->
                Text(
                    text = "• ${item.quantity}x ${item.product.name}",
                    color = NeutralGray200,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            if (order.items.size > 2) {
                Text(
                    text = "+ ${order.items.size - 2} more item(s)",
                    color = NeutralGray400,
                    fontSize = 11.sp
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Total (incl. GST)", color = NeutralGray400, fontSize = 10.sp)
                    Text(
                        text = order.formattedTotal,
                        color = FireRedLight,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = onViewInvoice,
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text("Invoice", fontSize = 11.sp, color = NeutralWhite)
                    }

                    Button(
                        onClick = onViewDetails,
                        colors = ButtonDefaults.buttonColors(containerColor = FireRed),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text("Track", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = NeutralWhite)
                    }
                }
            }
        }
    }
}
