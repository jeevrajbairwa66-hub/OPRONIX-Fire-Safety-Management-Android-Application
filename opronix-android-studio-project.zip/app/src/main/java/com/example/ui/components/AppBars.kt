package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.automirrored.outlined.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppLanguage
import com.example.model.UserRole
import com.example.ui.navigation.Screen
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OpronixTopAppBar(
    title: String,
    currentLanguage: AppLanguage,
    onLanguageToggle: () -> Unit,
    userRole: UserRole,
    onRoleSwitchClick: () -> Unit,
    unreadNotificationCount: Int,
    onNotificationsClick: () -> Unit,
    onEmergencyClick: () -> Unit,
    showBackButton: Boolean = false,
    onBackClick: () -> Unit = {}
) {
    Surface(
        color = CharcoalBlack,
        shadowElevation = 4.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
        ) {
            // Demo notice strip
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Brush.horizontalGradient(listOf(FireRedDark, SafetyOrangeDark)))
                    .padding(horizontal = 16.dp, vertical = 3.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "Demo Notice",
                        tint = NeutralWhite,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "DEMO MODE • Real-time Sandbox",
                        color = NeutralWhite,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                // Switch Role Pill
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = NeutralWhite.copy(alpha = 0.2f),
                    modifier = Modifier.clickable { onRoleSwitchClick() }
                ) {
                    Text(
                        text = "Role: ${userRole.name} ▾",
                        color = NeutralWhite,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                }
            }

            // Main Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(64.dp)
                    .padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (showBackButton) {
                    IconButton(
                        onClick = onBackClick,
                        modifier = Modifier.testTag("back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = NeutralWhite
                        )
                    }
                } else {
                    // Brand Icon / Flame Shield
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Brush.linearGradient(listOf(FireRed, SafetyOrange)))
                            .border(1.dp, NeutralWhite.copy(alpha = 0.3f), RoundedCornerShape(10.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocalFireDepartment,
                            contentDescription = "OPRONIX Logo",
                            tint = NeutralWhite,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                }

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = title,
                        color = NeutralWhite,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1
                    )
                    Text(
                        text = "Fire Safety Solutions • India",
                        color = NeutralGray400,
                        fontSize = 11.sp,
                        maxLines = 1
                    )
                }

                // Language toggle button
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = CharcoalCard,
                    border = androidx.compose.foundation.BorderStroke(1.dp, CharcoalBorder),
                    modifier = Modifier
                        .clickable { onLanguageToggle() }
                        .testTag("language_toggle_button")
                ) {
                    Text(
                        text = if (currentLanguage == AppLanguage.ENGLISH) "हिन्दी" else "ENG",
                        color = SafetyOrangeLight,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                // Emergency SOS Button
                IconButton(
                    onClick = onEmergencyClick,
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(FireRed)
                        .testTag("sos_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Call,
                        contentDescription = "Emergency Fire Assistance",
                        tint = NeutralWhite,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                // Notifications icon
                IconButton(
                    onClick = onNotificationsClick,
                    modifier = Modifier.testTag("notifications_button")
                ) {
                    BadgedBox(
                        badge = {
                            if (unreadNotificationCount > 0) {
                                Badge(containerColor = FireRed) {
                                    Text("$unreadNotificationCount", color = NeutralWhite)
                                }
                            }
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Notifications,
                            contentDescription = "Notifications",
                            tint = NeutralWhite
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun OpronixBottomBar(
    currentRoute: String?,
    onNavigate: (String) -> Unit,
    cartItemCount: Int
) {
    NavigationBar(
        containerColor = CharcoalBlack,
        tonalElevation = 8.dp,
        windowInsets = WindowInsets.navigationBars
    ) {
        val items = listOf(
            Triple(Screen.Home.route, "Home", Icons.Filled.Home to Icons.Outlined.Home),
            Triple(Screen.Products.route, "Products", Icons.Filled.LocalFireDepartment to Icons.Outlined.LocalFireDepartment),
            Triple(Screen.Services.route, "Services", Icons.Filled.Build to Icons.Outlined.Build),
            Triple(Screen.Orders.route, "Orders", Icons.AutoMirrored.Filled.ReceiptLong to Icons.AutoMirrored.Outlined.ReceiptLong),
            Triple(Screen.Profile.route, "Profile", Icons.Filled.Person to Icons.Outlined.Person)
        )

        items.forEach { (route, label, icons) ->
            val isSelected = currentRoute == route
            NavigationBarItem(
                selected = isSelected,
                onClick = {
                    if (currentRoute != route) {
                        onNavigate(route)
                    }
                },
                icon = {
                    if (route == Screen.Orders.route && cartItemCount > 0) {
                        BadgedBox(badge = {
                            Badge(containerColor = SafetyOrange) {
                                Text("$cartItemCount", color = CharcoalBlack, fontWeight = FontWeight.Bold)
                            }
                        }) {
                            Icon(
                                imageVector = if (isSelected) icons.first else icons.second,
                                contentDescription = label
                            )
                        }
                    } else {
                        Icon(
                            imageVector = if (isSelected) icons.first else icons.second,
                            contentDescription = label
                        )
                    }
                },
                label = {
                    Text(
                        text = label,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = NeutralWhite,
                    selectedTextColor = SafetyOrangeLight,
                    indicatorColor = FireRed,
                    unselectedIconColor = NeutralGray400,
                    unselectedTextColor = NeutralGray400
                ),
                modifier = Modifier.testTag("nav_$route")
            )
        }
    }
}
