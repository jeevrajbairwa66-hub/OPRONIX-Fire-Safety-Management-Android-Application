package com.example.ui.navigation

sealed class Screen(val route: String) {
    // Onboarding & Auth
    data object Splash : Screen("splash")
    data object Onboarding : Screen("onboarding")
    data object Login : Screen("login")
    data object Register : Screen("register")

    // Main Tabs
    data object Home : Screen("home")
    data object Products : Screen("products")
    data object Services : Screen("services")
    data object Orders : Screen("orders")
    data object Profile : Screen("profile")

    // Sub-screens
    data object ProductDetail : Screen("product_detail/{productId}") {
        fun createRoute(productId: String) = "product_detail/$productId"
    }
    data object Cart : Screen("cart")
    data object Checkout : Screen("checkout")
    data object OrderDetail : Screen("order_detail/{orderId}") {
        fun createRoute(orderId: String) = "order_detail/$orderId"
    }

    data object ServiceBooking : Screen("service_booking/{serviceType}") {
        fun createRoute(serviceType: String) = "service_booking/$serviceType"
    }
    data object ServiceTracking : Screen("service_tracking/{bookingId}") {
        fun createRoute(bookingId: String) = "service_tracking/$bookingId"
    }

    data object RequestQuotation : Screen("request_quotation")
    data object QuotationDetail : Screen("quotation_detail/{quoteId}") {
        fun createRoute(quoteId: String) = "quotation_detail/$quoteId"
    }

    data object AmcCatalogue : Screen("amc_catalogue")
    data object Notifications : Screen("notifications")
    data object ContactSupport : Screen("contact_support")

    // Role-specific screens
    data object AdminDashboard : Screen("admin_dashboard")
    data object AdminProducts : Screen("admin_products")
    data object AdminOrders : Screen("admin_orders")
    data object AdminServices : Screen("admin_services")
    data object AdminQuotations : Screen("admin_quotations")
    data object AdminSettings : Screen("admin_settings")

    data object TechnicianDashboard : Screen("technician_dashboard")
}
