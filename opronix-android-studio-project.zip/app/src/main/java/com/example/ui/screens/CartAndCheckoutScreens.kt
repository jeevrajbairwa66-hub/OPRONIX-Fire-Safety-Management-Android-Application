package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.theme.*

@Composable
fun CartScreen(
    cartItems: List<CartItem>,
    couponCode: String?,
    couponDiscount: Double,
    onUpdateQuantity: (String, Int) -> Unit,
    onRemoveItem: (String) -> Unit,
    onApplyCoupon: (String) -> Boolean,
    onRemoveCoupon: () -> Unit,
    onProceedToCheckout: () -> Unit,
    onContinueShopping: () -> Unit
) {
    var couponInput by remember { mutableStateOf("") }
    var couponMessage by remember { mutableStateOf<String?>(null) }
    var isCouponSuccess by remember { mutableStateOf(false) }

    val subtotal = cartItems.sumOf { it.totalItemPrice }
    val gst = (subtotal - couponDiscount).coerceAtLeast(0.0) * 0.18
    val delivery = if (cartItems.isNotEmpty()) 250.0 else 0.0
    val grandTotal = (subtotal - couponDiscount).coerceAtLeast(0.0) + gst + delivery

    if (cartItems.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(CharcoalBlack)
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Default.ShoppingCart,
                    contentDescription = null,
                    tint = NeutralGray400,
                    modifier = Modifier.size(64.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Your Cart is Empty",
                    color = NeutralWhite,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Explore our certified fire extinguishers and safety devices",
                    color = NeutralGray400,
                    fontSize = 13.sp
                )
                Spacer(modifier = Modifier.height(20.dp))
                Button(
                    onClick = onContinueShopping,
                    colors = ButtonDefaults.buttonColors(containerColor = FireRed),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Browse Products", fontWeight = FontWeight.Bold, color = NeutralWhite)
                }
            }
        }
    } else {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(CharcoalBlack)
        ) {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Text(
                        text = "Shopping Cart (${cartItems.size} items)",
                        color = NeutralWhite,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                items(cartItems, key = { it.product.id }) { item ->
                    CartItemRow(
                        item = item,
                        onIncrease = { onUpdateQuantity(item.product.id, item.quantity + 1) },
                        onDecrease = { onUpdateQuantity(item.product.id, item.quantity - 1) },
                        onRemove = { onRemoveItem(item.product.id) }
                    )
                }

                // Coupon code card
                item {
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = CharcoalCard),
                        border = androidx.compose.foundation.BorderStroke(1.dp, CharcoalBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "Apply Promotional Coupon",
                                color = NeutralWhite,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedTextField(
                                    value = couponInput,
                                    onValueChange = { couponInput = it; couponMessage = null },
                                    placeholder = { Text("e.g. FIRESAFE10", color = NeutralGray400, fontSize = 12.sp) },
                                    shape = RoundedCornerShape(10.dp),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = FireRed,
                                        unfocusedBorderColor = CharcoalBorder,
                                        focusedTextColor = NeutralWhite,
                                        unfocusedTextColor = NeutralWhite
                                    ),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(48.dp)
                                        .testTag("coupon_input")
                                )

                                Spacer(modifier = Modifier.width(8.dp))

                                Button(
                                    onClick = {
                                        val success = onApplyCoupon(couponInput)
                                        if (success) {
                                            couponMessage = "Coupon 'FIRESAFE10' applied (-10%)!"
                                            isCouponSuccess = true
                                        } else {
                                            couponMessage = "Invalid code. Try 'FIRESAFE10'."
                                            isCouponSuccess = false
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = SafetyOrange),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.height(48.dp)
                                ) {
                                    Text("Apply", color = CharcoalBlack, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            }

                            couponMessage?.let {
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = it,
                                    color = if (isCouponSuccess) StatusGreen else FireRedLight,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }

                // Order Price Breakdown Card
                item {
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = CharcoalCard),
                        border = androidx.compose.foundation.BorderStroke(1.dp, CharcoalBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = "Order Price Summary",
                                color = NeutralWhite,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Equipment Subtotal", color = NeutralGray400, fontSize = 12.sp)
                                Text("₹%,.0f".format(subtotal), color = NeutralWhite, fontSize = 12.sp)
                            }

                            if (couponDiscount > 0) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(top = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("Coupon Discount", color = StatusGreen, fontSize = 12.sp)
                                    Text("-₹%,.0f".format(couponDiscount), color = StatusGreen, fontSize = 12.sp)
                                }
                            }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("GST (18% Statutory)", color = NeutralGray400, fontSize = 12.sp)
                                Text("₹%,.0f".format(gst), color = NeutralWhite, fontSize = 12.sp)
                            }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Safe Logistics & Handling", color = NeutralGray400, fontSize = 12.sp)
                                Text("₹%,.0f".format(delivery), color = NeutralWhite, fontSize = 12.sp)
                            }

                            HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = CharcoalBorder)

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Grand Total (INR)", color = NeutralWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text(
                                    text = "₹%,.0f".format(grandTotal),
                                    color = FireRedLight,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 16.sp
                                )
                            }
                        }
                    }
                }
            }

            // Bottom Proceed Bar
            Surface(
                color = CharcoalCard,
                tonalElevation = 8.dp,
                border = androidx.compose.foundation.BorderStroke(1.dp, CharcoalBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .padding(16.dp)
                        .navigationBarsPadding(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Total Amount", color = NeutralGray400, fontSize = 11.sp)
                        Text(
                            text = "₹%,.0f".format(grandTotal),
                            color = FireRedLight,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 18.sp
                        )
                    }

                    Button(
                        onClick = onProceedToCheckout,
                        colors = ButtonDefaults.buttonColors(containerColor = FireRed),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .height(48.dp)
                            .testTag("checkout_button")
                    ) {
                        Text("Proceed to Checkout", fontWeight = FontWeight.Bold, color = NeutralWhite)
                    }
                }
            }
        }
    }
}

@Composable
fun CartItemRow(
    item: CartItem,
    onIncrease: () -> Unit,
    onDecrease: () -> Unit,
    onRemove: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = CharcoalCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, CharcoalBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(CharcoalElevated),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.LocalFireDepartment,
                    contentDescription = null,
                    tint = FireRedLight,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.product.name,
                    color = NeutralWhite,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    maxLines = 1
                )
                Text(
                    text = "${item.product.capacity} • ${item.product.formattedPrice} each",
                    color = NeutralGray400,
                    fontSize = 11.sp
                )
                Text(
                    text = item.formattedItemPrice,
                    color = FireRedLight,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }

            // Quantity buttons
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .background(CharcoalElevated, RoundedCornerShape(6.dp))
                    .padding(horizontal = 2.dp)
            ) {
                IconButton(onClick = onDecrease, modifier = Modifier.size(28.dp)) {
                    Text("-", color = NeutralWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
                Text(
                    text = "${item.quantity}",
                    color = NeutralWhite,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(horizontal = 6.dp)
                )
                IconButton(onClick = onIncrease, modifier = Modifier.size(28.dp)) {
                    Text("+", color = NeutralWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            }

            Spacer(modifier = Modifier.width(4.dp))

            IconButton(onClick = onRemove, modifier = Modifier.size(28.dp)) {
                Icon(Icons.Default.Delete, contentDescription = "Remove", tint = NeutralGray400, modifier = Modifier.size(16.dp))
            }
        }
    }
}

@Composable
fun CheckoutScreen(
    user: User?,
    cartItems: List<CartItem>,
    couponDiscount: Double,
    onPlaceOrder: (Address, PaymentMethod) -> Unit,
    onBackClick: () -> Unit
) {
    val addresses = user?.addresses ?: emptyList()
    var selectedAddressIndex by remember { mutableStateOf(0) }
    var selectedPaymentMethod by remember { mutableStateOf(PaymentMethod.PAY_ON_INVOICE) }
    var isPlacing by remember { mutableStateOf(false) }

    val subtotal = cartItems.sumOf { it.totalItemPrice }
    val gst = (subtotal - couponDiscount).coerceAtLeast(0.0) * 0.18
    val delivery = 250.0
    val grandTotal = (subtotal - couponDiscount).coerceAtLeast(0.0) + gst + delivery

    val activeAddress = if (addresses.isNotEmpty()) addresses[selectedAddressIndex.coerceIn(0, addresses.size - 1)] else Address(
        street = "Plot 42, Sitapura Industrial Area",
        city = "Jaipur",
        state = "Rajasthan",
        pincode = "302022"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CharcoalBlack)
    ) {
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBackClick) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = NeutralWhite)
                }
                Text(
                    text = "Checkout & Dispatch Details",
                    color = NeutralWhite,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Delivery Site Address Card
            Text(
                text = "Installation / Delivery Address",
                color = NeutralWhite,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))

            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = CharcoalCard),
                border = androidx.compose.foundation.BorderStroke(1.dp, CharcoalBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = activeAddress.label,
                        color = SafetyOrangeLight,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = activeAddress.formatted, color = NeutralWhite, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = "Recipient: ${user?.name ?: "Customer"} (${user?.phone ?: "+91 98290 12345"})", color = NeutralGray400, fontSize = 11.sp)
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Payment Architecture Selection
            Text(
                text = "Commercial Payment Mode",
                color = NeutralWhite,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                PaymentMethod.values().forEach { method ->
                    val isSelected = selectedPaymentMethod == method
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (isSelected) FireRed.copy(alpha = 0.15f) else CharcoalCard,
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (isSelected) FireRed else CharcoalBorder
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedPaymentMethod = method }
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = isSelected,
                                onClick = { selectedPaymentMethod = method },
                                colors = RadioButtonDefaults.colors(selectedColor = FireRed)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = method.displayName,
                                    color = NeutralWhite,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                                Text(
                                    text = when (method) {
                                        PaymentMethod.PAY_ON_INVOICE -> "GST Tax Invoice issued upon delivery (15-day credit for verified firms)"
                                        PaymentMethod.CASH_ON_DELIVERY -> "Pay field delivery agent in cash/UPI upon physical inspection"
                                        PaymentMethod.ONLINE_UPI_GATEWAY -> "Payment gateway integration architecture (Demo Mode: Instant simulated clearance)"
                                    },
                                    color = NeutralGray400,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Demo disclaimer card
            Card(
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = CharcoalElevated),
                border = androidx.compose.foundation.BorderStroke(1.dp, CharcoalBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Info, contentDescription = null, tint = SafetyOrangeLight, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Demo Mode: No live financial transaction will be charged. Clicking confirm places an active demo order in your order history.",
                        color = NeutralGray200,
                        fontSize = 11.sp
                    )
                }
            }
        }

        // Place Order Footer
        Surface(
            color = CharcoalCard,
            tonalElevation = 8.dp,
            border = androidx.compose.foundation.BorderStroke(1.dp, CharcoalBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .padding(16.dp)
                    .navigationBarsPadding(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Total (incl. 18% GST)", color = NeutralGray400, fontSize = 11.sp)
                    Text(
                        text = "₹%,.0f".format(grandTotal),
                        color = FireRedLight,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 18.sp
                    )
                }

                Button(
                    onClick = {
                        isPlacing = true
                        onPlaceOrder(activeAddress, selectedPaymentMethod)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = FireRed),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .height(48.dp)
                        .testTag("confirm_order_button")
                ) {
                    Text("Confirm Order", fontWeight = FontWeight.Bold, color = NeutralWhite)
                }
            }
        }
    }
}
