package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.components.ServiceCard
import com.example.ui.theme.*
import java.util.UUID

@Composable
fun ServicesScreen(
    bookings: List<ServiceBooking>,
    onSelectServiceToBook: (ServiceType) -> Unit,
    onViewBookingTracking: (String) -> Unit
) {
    var selectedTab by remember { mutableStateOf(0) } // 0: Available Services, 1: My Bookings

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CharcoalBlack)
            .padding(16.dp)
    ) {
        Text(
            text = "Fire Safety Services",
            color = NeutralWhite,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "Certified engineering, installation & doorstep maintenance across India",
            color = NeutralGray400,
            fontSize = 12.sp
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Tab Row
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = CharcoalCard,
            contentColor = FireRed
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("Service Catalogue", fontWeight = FontWeight.Bold) }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("My Bookings (${bookings.size})", fontWeight = FontWeight.Bold) }
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        if (selectedTab == 0) {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(ServiceType.values()) { service ->
                    ServiceCard(
                        serviceType = service,
                        onRequestService = { onSelectServiceToBook(service) }
                    )
                }
            }
        } else {
            if (bookings.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.EventBusy,
                            contentDescription = null,
                            tint = NeutralGray400,
                            modifier = Modifier.size(50.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("No active service bookings", color = NeutralWhite, fontWeight = FontWeight.Bold)
                        Text("Book an extinguisher refill or audit above", color = NeutralGray400, fontSize = 12.sp)
                    }
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(bookings, key = { it.id }) { booking ->
                        BookingItemCard(
                            booking = booking,
                            onClick = { onViewBookingTracking(booking.id) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun BookingItemCard(
    booking: ServiceBooking,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = CharcoalCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, CharcoalBorder),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = booking.serviceType.title,
                        color = NeutralWhite,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Text(
                        text = "Ref: #${booking.bookingNumber} • ${booking.preferredDate}",
                        color = NeutralGray400,
                        fontSize = 11.sp
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = when (booking.status) {
                        BookingStatus.PENDING -> StatusAmberBg
                        BookingStatus.CONFIRMED, BookingStatus.TECHNICIAN_ASSIGNED, BookingStatus.IN_PROGRESS -> StatusBlueBg
                        BookingStatus.COMPLETED -> StatusGreenBg
                        BookingStatus.CANCELLED -> StatusRedBg
                    }
                ) {
                    Text(
                        text = booking.status.displayName,
                        color = when (booking.status) {
                            BookingStatus.PENDING -> StatusAmber
                            BookingStatus.CONFIRMED, BookingStatus.TECHNICIAN_ASSIGNED, BookingStatus.IN_PROGRESS -> StatusBlue
                            BookingStatus.COMPLETED -> StatusGreen
                            BookingStatus.CANCELLED -> FireRed
                        },
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "Site: ${booking.siteAddress}",
                color = NeutralGray200,
                fontSize = 12.sp,
                maxLines = 1
            )
            Text(
                text = "Equipment: ${booking.equipmentType} (${booking.estimatedUnits} units)",
                color = SafetyOrangeLight,
                fontSize = 11.sp
            )

            booking.assignedTechnicianName?.let { tech ->
                Spacer(modifier = Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Engineering, contentDescription = null, tint = StatusGreen, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Technician: $tech (${booking.assignedTechnicianPhone ?: ""})",
                        color = StatusGreen,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Button(
                onClick = onClick,
                colors = ButtonDefaults.buttonColors(containerColor = FireRed),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Track Service Visit", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = NeutralWhite)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ServiceBookingScreen(
    serviceType: ServiceType,
    user: User?,
    onSubmitBooking: (ServiceBooking) -> Unit,
    onBackClick: () -> Unit
) {
    var propertyType by remember { mutableStateOf(PropertyType.COMMERCIAL_OFFICE) }
    var preferredDate by remember { mutableStateOf("Tomorrow (10:00 AM - 1:00 PM)") }
    var equipmentType by remember { mutableStateOf("ABC 4kg Extinguishers") }
    var estimatedUnitsText by remember { mutableStateOf("6") }
    var siteAddress by remember { mutableStateOf(user?.addresses?.firstOrNull()?.formatted ?: "Plot 42, Sitapura Industrial Area, Jaipur") }
    var problemDescription by remember { mutableStateOf("") }
    var customerPhone by remember { mutableStateOf(user?.phone ?: "+91 98290 12345") }
    var isSubmitted by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CharcoalBlack)
    ) {
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBackClick) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = NeutralWhite)
                }
                Column {
                    Text(
                        text = "Book ${serviceType.title}",
                        color = NeutralWhite,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Base Assessment Fee: ₹%,.0f".format(serviceType.baseFee),
                        color = SafetyOrangeLight,
                        fontSize = 12.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Property Type
            Text("Facility / Property Type", color = NeutralWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(6.dp))

            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(
                    PropertyType.COMMERCIAL_OFFICE,
                    PropertyType.INDUSTRIAL_FACTORY,
                    PropertyType.WAREHOUSE_LOGISTICS,
                    PropertyType.RESIDENTIAL_APARTMENT
                ).forEach { pt ->
                    val isSelected = propertyType == pt
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (isSelected) FireRed.copy(alpha = 0.2f) else CharcoalCard,
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) FireRed else CharcoalBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { propertyType = pt }
                    ) {
                        Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = isSelected, onClick = { propertyType = pt })
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(pt.label, color = NeutralWhite, fontSize = 12.sp)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Equipment & Units
            OutlinedTextField(
                value = equipmentType,
                onValueChange = { equipmentType = it },
                label = { Text("Equipment Type & Rating") },
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = FireRed,
                    unfocusedBorderColor = CharcoalBorder,
                    focusedTextColor = NeutralWhite,
                    unfocusedTextColor = NeutralWhite
                ),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = estimatedUnitsText,
                onValueChange = { estimatedUnitsText = it },
                label = { Text("Estimated Number of Units") },
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = FireRed,
                    unfocusedBorderColor = CharcoalBorder,
                    focusedTextColor = NeutralWhite,
                    unfocusedTextColor = NeutralWhite
                ),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = preferredDate,
                onValueChange = { preferredDate = it },
                label = { Text("Preferred Visit Date & Time") },
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = FireRed,
                    unfocusedBorderColor = CharcoalBorder,
                    focusedTextColor = NeutralWhite,
                    unfocusedTextColor = NeutralWhite
                ),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = siteAddress,
                onValueChange = { siteAddress = it },
                label = { Text("Site Address (Where service is needed)") },
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = FireRed,
                    unfocusedBorderColor = CharcoalBorder,
                    focusedTextColor = NeutralWhite,
                    unfocusedTextColor = NeutralWhite
                ),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = problemDescription,
                onValueChange = { problemDescription = it },
                label = { Text("Requirements or Problem Description (Optional)") },
                minLines = 3,
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = FireRed,
                    unfocusedBorderColor = CharcoalBorder,
                    focusedTextColor = NeutralWhite,
                    unfocusedTextColor = NeutralWhite
                ),
                modifier = Modifier.fillMaxWidth()
            )
        }

        // Bottom CTA
        Surface(
            color = CharcoalCard,
            tonalElevation = 8.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Button(
                onClick = {
                    val code = (100..999).random()
                    val units = estimatedUnitsText.toIntOrNull() ?: 1
                    val booking = ServiceBooking(
                        id = "SB-2026-$code",
                        bookingNumber = "OPR-SRV-$code",
                        serviceType = serviceType,
                        customerId = user?.id ?: "usr_demo_1",
                        customerName = user?.name ?: "Customer",
                        customerPhone = customerPhone,
                        siteAddress = siteAddress,
                        propertyType = propertyType,
                        preferredDate = preferredDate,
                        preferredTimeSlot = "10:00 AM - 1:00 PM",
                        equipmentType = equipmentType,
                        estimatedUnits = units,
                        problemDescription = problemDescription,
                        status = BookingStatus.PENDING,
                        estimatedCost = serviceType.baseFee * units.coerceAtLeast(1)
                    )
                    onSubmitBooking(booking)
                },
                colors = ButtonDefaults.buttonColors(containerColor = FireRed),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .height(50.dp)
                    .testTag("submit_service_booking_button")
            ) {
                Text("Confirm Service Request", fontWeight = FontWeight.Bold, color = NeutralWhite)
            }
        }
    }
}

@Composable
fun ServiceTrackingScreen(
    booking: ServiceBooking,
    onBackClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CharcoalBlack)
    ) {
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBackClick) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = NeutralWhite)
                }
                Text(
                    text = "Service Visit #${booking.bookingNumber}",
                    color = NeutralWhite,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Service Header Card
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = CharcoalCard),
                border = androidx.compose.foundation.BorderStroke(1.dp, CharcoalBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = booking.serviceType.title, color = NeutralWhite, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text(text = "Status: ${booking.status.displayName}", color = SafetyOrangeLight, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = "Preferred Schedule: ${booking.preferredDate} (${booking.preferredTimeSlot})", color = NeutralGray200, fontSize = 12.sp)
                    Text(text = "Site: ${booking.siteAddress}", color = NeutralGray400, fontSize = 12.sp)
                    Text(text = "Scope: ${booking.equipmentType} - ${booking.estimatedUnits} unit(s)", color = NeutralGray400, fontSize = 12.sp)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Assigned Engineer Card
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = CharcoalCard),
                border = androidx.compose.foundation.BorderStroke(1.dp, CharcoalBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "Field Technician Details", color = NeutralWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(8.dp))

                    if (booking.assignedTechnicianName != null) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(StatusGreen),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Person, contentDescription = null, tint = NeutralWhite)
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(booking.assignedTechnicianName, color = NeutralWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text("Verified Safety Engineer • ${booking.assignedTechnicianPhone ?: ""}", color = NeutralGray400, fontSize = 11.sp)
                            }
                        }
                    } else {
                        Text(
                            text = "Technician assignment in progress. OPRONIX dispatch will allocate an authorized safety engineer shortly.",
                            color = NeutralGray400,
                            fontSize = 12.sp
                        )
                    }

                    if (booking.technicianNotes.isNotBlank()) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(text = "Site Notes: ${booking.technicianNotes}", color = SafetyOrangeLight, fontSize = 12.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Cost Summary Card
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = CharcoalCard),
                border = androidx.compose.foundation.BorderStroke(1.dp, CharcoalBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Estimated Cost", color = NeutralGray400, fontSize = 12.sp)
                        Text(booking.formattedCost, color = FireRedLight, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = CharcoalElevated
                    ) {
                        Text(
                            text = "GST 18% as applicable",
                            color = NeutralGray400,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }
    }
}
