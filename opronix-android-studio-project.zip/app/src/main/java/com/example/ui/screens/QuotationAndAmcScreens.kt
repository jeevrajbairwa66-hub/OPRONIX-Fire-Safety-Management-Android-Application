package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.theme.*

@Composable
fun RequestQuotationScreen(
    user: User?,
    preselectedProduct: Product?,
    onSubmitQuotation: (Quotation) -> Unit,
    onBackClick: () -> Unit
) {
    var customerName by remember { mutableStateOf(user?.name ?: "Rajesh Sharma") }
    var companyName by remember { mutableStateOf(user?.companyName ?: "Sharma Enterprises Pvt Ltd") }
    var email by remember { mutableStateOf(user?.email ?: "rajesh.sharma@example.com") }
    var phone by remember { mutableStateOf(user?.phone ?: "+91 98290 12345") }
    var siteAddress by remember { mutableStateOf(user?.addresses?.firstOrNull()?.formatted ?: "Plot 42, Sitapura Industrial Area, Jaipur") }
    var requirements by remember {
        mutableStateOf(
            if (preselectedProduct != null) "Inquiry for bulk procurement of: ${preselectedProduct.name} (Estimated 20 units) along with installation and testing."
            else "Requirement for complete fire protection installation for a 15,000 sq.ft industrial facility including fire hydrant system, smoke detectors, and 30x ABC fire extinguishers."
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CharcoalBlack)
    ) {
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBackClick) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = NeutralWhite)
                }
                Text(
                    text = "Request Official Quotation",
                    color = NeutralWhite,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "Get an itemized commercial proposal with GST compliance from our certified safety estimating team within 24 hours.",
                color = NeutralGray400,
                fontSize = 12.sp,
                lineHeight = 17.sp
            )

            Spacer(modifier = Modifier.height(16.dp))

            OutlinedTextField(
                value = customerName,
                onValueChange = { customerName = it },
                label = { Text("Contact Person Name") },
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = FireRed,
                    unfocusedBorderColor = CharcoalBorder,
                    focusedTextColor = NeutralWhite,
                    unfocusedTextColor = NeutralWhite
                ),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = companyName,
                onValueChange = { companyName = it },
                label = { Text("Company / Establishment Name") },
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = FireRed,
                    unfocusedBorderColor = CharcoalBorder,
                    focusedTextColor = NeutralWhite,
                    unfocusedTextColor = NeutralWhite
                ),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Phone (+91)") },
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = FireRed,
                        unfocusedBorderColor = CharcoalBorder,
                        focusedTextColor = NeutralWhite,
                        unfocusedTextColor = NeutralWhite
                    ),
                    modifier = Modifier.weight(1f)
                )

                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Official Email") },
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = FireRed,
                        unfocusedBorderColor = CharcoalBorder,
                        focusedTextColor = NeutralWhite,
                        unfocusedTextColor = NeutralWhite
                    ),
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = siteAddress,
                onValueChange = { siteAddress = it },
                label = { Text("Site / Facility Location") },
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = FireRed,
                    unfocusedBorderColor = CharcoalBorder,
                    focusedTextColor = NeutralWhite,
                    unfocusedTextColor = NeutralWhite
                ),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = requirements,
                onValueChange = { requirements = it },
                label = { Text("Detailed Fire Protection Requirements") },
                minLines = 4,
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = FireRed,
                    unfocusedBorderColor = CharcoalBorder,
                    focusedTextColor = NeutralWhite,
                    unfocusedTextColor = NeutralWhite
                ),
                modifier = Modifier.fillMaxWidth()
            )
        }

        Surface(
            color = CharcoalCard,
            tonalElevation = 8.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Button(
                onClick = {
                    val code = (100..999).random()
                    val quote = Quotation(
                        id = "QT-2026-$code",
                        quoteReference = "OPR-EST-$code",
                        customerId = user?.id ?: "usr_demo_1",
                        customerName = customerName,
                        companyName = companyName,
                        email = email,
                        phone = phone,
                        siteAddress = siteAddress,
                        requirements = requirements,
                        status = QuotationStatus.REQUESTED
                    )
                    onSubmitQuotation(quote)
                },
                colors = ButtonDefaults.buttonColors(containerColor = FireRed),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .height(50.dp)
                    .testTag("submit_quotation_button")
            ) {
                Text("Submit Quotation Request", fontWeight = FontWeight.Bold, color = NeutralWhite)
            }
        }
    }
}

@Composable
fun QuotationDetailScreen(
    quotation: Quotation,
    onBackClick: () -> Unit
) {
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CharcoalBlack)
    ) {
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBackClick) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = NeutralWhite)
                }
                Text(
                    text = "Quotation #${quotation.quoteReference}",
                    color = NeutralWhite,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Quotation Status Card
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = CharcoalCard),
                border = androidx.compose.foundation.BorderStroke(1.dp, CharcoalBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Status: ${quotation.status.displayName}",
                        color = when (quotation.status) {
                            QuotationStatus.REQUESTED, QuotationStatus.UNDER_REVIEW -> StatusAmber
                            QuotationStatus.QUOTATION_PREPARED, QuotationStatus.ACCEPTED -> StatusGreen
                            QuotationStatus.REJECTED -> FireRed
                        },
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = "Customer: ${quotation.customerName} (${quotation.companyName})", color = NeutralWhite, fontSize = 12.sp)
                    Text(text = "Site: ${quotation.siteAddress}", color = NeutralGray400, fontSize = 12.sp)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Requirements Details
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = CharcoalCard),
                border = androidx.compose.foundation.BorderStroke(1.dp, CharcoalBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Requested Scope of Work", color = NeutralWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = quotation.requirements, color = NeutralGray200, fontSize = 12.sp, lineHeight = 18.sp)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Quoted Pricing Breakdown (if prepared)
            if (quotation.quotedGrandTotal != null) {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = CharcoalCard),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CharcoalBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Prepared Commercial Estimate", color = NeutralWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Subtotal", color = NeutralGray400, fontSize = 12.sp)
                            Text("₹%,.0f".format(quotation.quotedSubtotal ?: 0.0), color = NeutralWhite, fontSize = 12.sp)
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("GST (18% Statutory)", color = NeutralGray400, fontSize = 12.sp)
                            Text("₹%,.0f".format(quotation.quotedGst ?: 0.0), color = NeutralWhite, fontSize = 12.sp)
                        }

                        HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = CharcoalBorder)

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Grand Quoted Total", color = NeutralWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(
                                text = quotation.formattedQuotedTotal ?: "",
                                color = FireRedLight,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 16.sp
                            )
                        }

                        if (quotation.adminNotes.isNotBlank()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(text = "Estimator Note: ${quotation.adminNotes}", color = SafetyOrangeLight, fontSize = 11.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // PDF Export / Share
                Button(
                    onClick = {
                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(
                                Intent.EXTRA_TEXT,
                                "OPRONIX Fire Safety Solutions - Official Quotation #${quotation.quoteReference}\n" +
                                        "Company: ${quotation.companyName}\n" +
                                        "Total Amount: ${quotation.formattedQuotedTotal}\n" +
                                        "Terms: ${quotation.termsAndConditions}"
                            )
                        }
                        context.startActivity(Intent.createChooser(shareIntent, "Share Quotation Summary"))
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = FireRed),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.PictureAsPdf, contentDescription = null, tint = NeutralWhite)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Export / Share Proposal PDF Summary", fontWeight = FontWeight.Bold, color = NeutralWhite)
                }
            } else {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = CharcoalElevated),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CharcoalBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.HourglassTop, contentDescription = null, tint = StatusAmber, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "OPRONIX engineering estimators are analyzing your facility requirements. Final quote will be published here shortly.",
                            color = NeutralGray200,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AmcCatalogueScreen(
    contracts: List<AmcContract>,
    onRequestAmc: (AmcTier) -> Unit,
    onBackClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CharcoalBlack)
    ) {
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBackClick) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = NeutralWhite)
                }
                Text(
                    text = "Annual Maintenance Contracts",
                    color = NeutralWhite,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "Guaranteed 365-day fire safety compliance under NBC 2016 for commercial complexes, manufacturing units, and hospitals.",
                color = NeutralGray400,
                fontSize = 12.sp,
                lineHeight = 17.sp
            )

            // Existing Active Contract (if any)
            if (contracts.isNotEmpty()) {
                Spacer(modifier = Modifier.height(16.dp))
                Text("Your Active AMC Contracts", color = SafetyOrangeLight, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(modifier = Modifier.height(8.dp))

                contracts.forEach { contract ->
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = CharcoalCard),
                        border = androidx.compose.foundation.BorderStroke(1.dp, StatusGreen),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(contract.tier.title, color = NeutralWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Surface(shape = RoundedCornerShape(6.dp), color = StatusGreenBg) {
                                    Text(contract.status.label, color = StatusGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Contract: #${contract.contractNumber} • Annual: ${contract.formattedFee}", color = SafetyOrangeLight, fontSize = 12.sp)
                            Text("Audits: ${contract.quarterlyAuditsDone} of ${contract.totalQuarterlyAudits} completed • Next audit: ${contract.nextScheduledAuditDate}", color = NeutralGray400, fontSize = 11.sp)
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text("Select an AMC Tier", color = NeutralWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(10.dp))

            AmcTier.values().forEach { tier ->
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = CharcoalCard),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CharcoalBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(tier.title, color = NeutralWhite, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text("₹%,.0f/yr".format(tier.annualPrice), color = FireRedLight, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                        }

                        Text(tier.hindiTitle, color = SafetyOrangeLight, fontSize = 11.sp)

                        Spacer(modifier = Modifier.height(10.dp))

                        val features = when (tier) {
                            AmcTier.ESSENTIAL -> listOf(
                                "4 Quarterly Certified Inspections",
                                "Hydrostatic pressure testing",
                                "Free minor valve washer replacements",
                                "Digital audit compliance log"
                            )
                            AmcTier.COMMERCIAL_PRO -> listOf(
                                "All Essential features included",
                                "Free refilling on genuine discharge",
                                "Alarm panel & detector loop testing",
                                "Fire NOC renewal assistance certificate"
                            )
                            AmcTier.INDUSTRIAL_ENTERPRISE -> listOf(
                                "Comprehensive Hydrant & Sprinkler system coverage",
                                "Diesel engine fire pump routine servicing",
                                "Staff fire mock drill & live extinguisher training",
                                "24/7 Priority Emergency dispatch support"
                            )
                        }

                        features.forEach { feat ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(vertical = 3.dp)
                            ) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = StatusGreen, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(feat, color = NeutralGray200, fontSize = 12.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Button(
                            onClick = { onRequestAmc(tier) },
                            colors = ButtonDefaults.buttonColors(containerColor = FireRed),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Book ${tier.title}", fontWeight = FontWeight.Bold, color = NeutralWhite)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
            }
        }
    }
}
