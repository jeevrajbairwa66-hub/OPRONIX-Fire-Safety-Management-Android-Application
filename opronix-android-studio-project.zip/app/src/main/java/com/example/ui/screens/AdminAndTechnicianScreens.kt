package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.*
import com.example.ui.theme.*

@Composable
fun AdminDashboardScreen(
    orders: List<Order>,
    products: List<Product>,
    bookings: List<ServiceBooking>,
    quotations: List<Quotation>,
    onNavigateToProductManage: () -> Unit,
    onNavigateToOrderManage: () -> Unit,
    onNavigateToServiceManage: () -> Unit,
    onNavigateToQuotationManage: () -> Unit,
    onBackClick: () -> Unit
) {
    // Verified revenue calculation (paid or demo-verified orders only, not cancelled or pending COD)
    val verifiedPaidRevenue = remember(orders) {
        orders.filter { it.status != OrderStatus.CANCELLED && it.paymentStatus != PaymentStatus.PENDING }
            .sumOf { it.totalAmount }
    }
    val pendingBookingsCount = remember(bookings) {
        bookings.count { it.status == BookingStatus.PENDING || it.status == BookingStatus.CONFIRMED }
    }
    val pendingQuotesCount = remember(quotations) {
        quotations.count { it.status == QuotationStatus.REQUESTED || it.status == QuotationStatus.UNDER_REVIEW }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CharcoalBlack)
    ) {
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBackClick) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = NeutralWhite)
                }
                Column {
                    Text(
                        text = "OPRONIX Admin Console",
                        color = NeutralWhite,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Executive management & operations dashboard",
                        color = FireRedLight,
                        fontSize = 11.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // KPI Grid
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                AdminStatCard(
                    title = "Verified Revenue",
                    value = "₹%,.0f".format(verifiedPaidRevenue),
                    subtitle = "Paid commercial orders",
                    icon = Icons.Default.CurrencyRupee,
                    modifier = Modifier.weight(1f)
                )

                AdminStatCard(
                    title = "Pending Services",
                    value = "$pendingBookingsCount Visits",
                    subtitle = "Needs technician dispatch",
                    icon = Icons.Default.Build,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                AdminStatCard(
                    title = "Equipment Lines",
                    value = "${products.size} Products",
                    subtitle = "15 Indian IS Categories",
                    icon = Icons.Default.Inventory,
                    modifier = Modifier.weight(1f)
                )

                AdminStatCard(
                    title = "Quotation Requests",
                    value = "$pendingQuotesCount Pending",
                    subtitle = "Needs estimator review",
                    icon = Icons.Default.RequestQuote,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text("Operational Management Modules", color = NeutralWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(10.dp))

            AdminModuleButton(
                title = "Inventory & Products CRUD",
                description = "Add products, update stock quantities, edit pricing & certifications",
                icon = Icons.Default.Inventory2,
                onClick = onNavigateToProductManage
            )

            Spacer(modifier = Modifier.height(10.dp))

            AdminModuleButton(
                title = "Orders & Dispatch Management",
                description = "Advance order lifecycle: Confirmed → Dispatched → Delivered",
                icon = Icons.Default.LocalShipping,
                onClick = onNavigateToOrderManage
            )

            Spacer(modifier = Modifier.height(10.dp))

            AdminModuleButton(
                title = "Field Services & Technician Allocation",
                description = "Assign technicians to pending bookings & review site safety reports",
                icon = Icons.Default.Engineering,
                onClick = onNavigateToServiceManage
            )

            Spacer(modifier = Modifier.height(10.dp))

            AdminModuleButton(
                title = "Commercial Quotations Review",
                description = "Prepare custom pricing estimates and release proposals to clients",
                icon = Icons.Default.Calculate,
                onClick = onNavigateToQuotationManage
            )
        }
    }
}

@Composable
fun AdminStatCard(
    title: String,
    value: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = CharcoalCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, CharcoalBorder),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(CharcoalElevated),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = SafetyOrangeLight, modifier = Modifier.size(18.dp))
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(value, color = NeutralWhite, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
            Text(title, color = SafetyOrangeLight, fontWeight = FontWeight.SemiBold, fontSize = 11.sp)
            Spacer(modifier = Modifier.height(2.dp))
            Text(subtitle, color = NeutralGray400, fontSize = 10.sp)
        }
    }
}

@Composable
fun AdminModuleButton(
    title: String,
    description: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = CharcoalCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, CharcoalBorder),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(FireRed.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = FireRedLight, modifier = Modifier.size(20.dp))
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, color = NeutralWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text(description, color = NeutralGray400, fontSize = 11.sp)
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = NeutralGray400)
        }
    }
}

@Composable
fun AdminProductManageScreen(
    products: List<Product>,
    onAddProduct: (Product) -> Unit,
    onDeleteProduct: (String) -> Unit,
    onBackClick: () -> Unit
) {
    var showAddDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CharcoalBlack)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBackClick) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = NeutralWhite)
                }
                Text("Manage Products (${products.size})", color = NeutralWhite, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            }

            Button(
                onClick = { showAddDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = FireRed),
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Add New", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = NeutralWhite)
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(products, key = { it.id }) { prod ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = CharcoalCard),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CharcoalBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(prod.name, color = NeutralWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("${prod.capacity} • ${prod.formattedPrice} • Stock: ${prod.stockQuantity}", color = SafetyOrangeLight, fontSize = 11.sp)
                            Text(prod.standardCompliance, color = NeutralGray400, fontSize = 10.sp)
                        }

                        IconButton(onClick = { onDeleteProduct(prod.id) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = FireRedLight)
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AddProductDialog(
            onDismiss = { showAddDialog = false },
            onSave = { newProd ->
                onAddProduct(newProd)
                showAddDialog = false
            }
        )
    }
}

@Composable
fun AddProductDialog(
    onDismiss: () -> Unit,
    onSave: (Product) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var capacity by remember { mutableStateOf("") }
    var priceText by remember { mutableStateOf("") }
    var stockText by remember { mutableStateOf("25") }
    var selectedCat by remember { mutableStateOf(ProductCategory.ABC_EXTINGUISHER) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = CharcoalBlack,
            border = androidx.compose.foundation.BorderStroke(1.dp, CharcoalBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("Add Fire Safety Product", color = NeutralWhite, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Product Title") },
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = NeutralWhite, unfocusedTextColor = NeutralWhite),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = capacity,
                    onValueChange = { capacity = it },
                    label = { Text("Capacity / Rating (e.g. 6 kg MAP 90%)") },
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = NeutralWhite, unfocusedTextColor = NeutralWhite),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = priceText,
                        onValueChange = { priceText = it },
                        label = { Text("Price (INR)") },
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = NeutralWhite, unfocusedTextColor = NeutralWhite),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = stockText,
                        onValueChange = { stockText = it },
                        label = { Text("Stock Quantity") },
                        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = NeutralWhite, unfocusedTextColor = NeutralWhite),
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel", color = NeutralGray400)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val price = priceText.toDoubleOrNull() ?: 1000.0
                            val stock = stockText.toIntOrNull() ?: 10
                            val newProd = Product(
                                id = "prod_custom_" + System.currentTimeMillis().toString().takeLast(6),
                                name = if (name.isNotBlank()) name else "OPRONIX Custom Product",
                                category = selectedCat,
                                price = price,
                                originalPrice = price * 1.25,
                                capacity = if (capacity.isNotBlank()) capacity else "Standard IS Certified",
                                description = "Admin added commercial fire protection unit. Fully compliant with standard specifications.",
                                stockQuantity = stock
                            )
                            onSave(newProd)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = FireRed)
                    ) {
                        Text("Save Product", color = NeutralWhite)
                    }
                }
            }
        }
    }
}

@Composable
fun AdminOrderManageScreen(
    orders: List<Order>,
    onUpdateStatus: (orderId: String, newStatus: OrderStatus) -> Unit,
    onBackClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CharcoalBlack)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBackClick) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = NeutralWhite)
            }
            Text("Manage Orders (${orders.size})", color = NeutralWhite, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }

        Spacer(modifier = Modifier.height(14.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(orders, key = { it.id }) { order ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = CharcoalCard),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CharcoalBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("#${order.id}", color = NeutralWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(order.status.displayName, color = SafetyOrangeLight, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        Text("Customer: ${order.customerName} • Total: ${order.formattedTotal}", color = NeutralGray200, fontSize = 12.sp)
                        Text("Delivery: ${order.deliveryAddress.formatted}", color = NeutralGray400, fontSize = 11.sp)

                        Spacer(modifier = Modifier.height(10.dp))

                        // Status Advance Buttons
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            if (order.status == OrderStatus.PENDING) {
                                Button(
                                    onClick = { onUpdateStatus(order.id, OrderStatus.CONFIRMED) },
                                    colors = ButtonDefaults.buttonColors(containerColor = StatusBlue),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Confirm", fontSize = 11.sp, color = NeutralWhite)
                                }
                            }
                            if (order.status == OrderStatus.CONFIRMED) {
                                Button(
                                    onClick = { onUpdateStatus(order.id, OrderStatus.PROCESSING) },
                                    colors = ButtonDefaults.buttonColors(containerColor = SafetyOrange),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Dispatch", fontSize = 11.sp, color = CharcoalBlack)
                                }
                            }
                            if (order.status == OrderStatus.PROCESSING || order.status == OrderStatus.SHIPPED) {
                                Button(
                                    onClick = { onUpdateStatus(order.id, OrderStatus.DELIVERED) },
                                    colors = ButtonDefaults.buttonColors(containerColor = StatusGreen),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Mark Delivered", fontSize = 11.sp, color = NeutralWhite)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AdminServiceManageScreen(
    bookings: List<ServiceBooking>,
    onAssignTechnician: (bookingId: String, techId: String, techName: String, techPhone: String) -> Unit,
    onBackClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CharcoalBlack)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBackClick) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = NeutralWhite)
            }
            Text("Service & Technician Dispatch", color = NeutralWhite, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }

        Spacer(modifier = Modifier.height(14.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(bookings, key = { it.id }) { booking ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = CharcoalCard),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CharcoalBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(booking.serviceType.title, color = NeutralWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("Customer: ${booking.customerName} (${booking.customerPhone})", color = SafetyOrangeLight, fontSize = 12.sp)
                        Text("Site: ${booking.siteAddress}", color = NeutralGray200, fontSize = 11.sp)
                        Text("Preferred: ${booking.preferredDate} • Units: ${booking.estimatedUnits}", color = NeutralGray400, fontSize = 11.sp)

                        Spacer(modifier = Modifier.height(8.dp))

                        if (booking.assignedTechnicianName == null) {
                            Button(
                                onClick = {
                                    onAssignTechnician(booking.id, "tech_01", "Vikram Singh", "+91 98291 99887")
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = FireRed),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Assign Vikram Singh (Sr. Tech)", fontSize = 11.sp, color = NeutralWhite)
                            }
                        } else {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Check, contentDescription = null, tint = StatusGreen, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Assigned: ${booking.assignedTechnicianName}", color = StatusGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AdminQuotationManageScreen(
    quotations: List<Quotation>,
    onPrepareQuote: (quoteId: String, subtotal: Double, gst: Double, total: Double, notes: String) -> Unit,
    onBackClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CharcoalBlack)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBackClick) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = NeutralWhite)
            }
            Text("Quotations & Bids (${quotations.size})", color = NeutralWhite, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }

        Spacer(modifier = Modifier.height(14.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(quotations, key = { it.id }) { quote ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = CharcoalCard),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CharcoalBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text("Quote #${quote.quoteReference}", color = NeutralWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("Company: ${quote.companyName} (${quote.customerName})", color = SafetyOrangeLight, fontSize = 12.sp)
                        Text("Scope: ${quote.requirements}", color = NeutralGray200, fontSize = 11.sp, maxLines = 2)

                        Spacer(modifier = Modifier.height(8.dp))

                        if (quote.quotedGrandTotal == null) {
                            Button(
                                onClick = {
                                    val subtotal = 38500.0
                                    val gst = subtotal * 0.18
                                    val grand = subtotal + gst
                                    onPrepareQuote(quote.id, subtotal, gst, grand, "Official proposal with 30-day validity")
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = FireRed),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Approve & Submit Estimate (₹45,430)", fontSize = 11.sp, color = NeutralWhite)
                            }
                        } else {
                            Text("Quoted: ${quote.formattedQuotedTotal} • Ready for Client", color = StatusGreen, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TechnicianDashboardScreen(
    bookings: List<ServiceBooking>,
    onUpdateStatus: (bookingId: String, status: BookingStatus, notes: String) -> Unit,
    onBackClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CharcoalBlack)
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBackClick) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = NeutralWhite)
            }
            Column {
                Text("Field Technician Portal", color = NeutralWhite, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("Engineer: Vikram Singh • Jaipur Sector", color = SafetyOrangeLight, fontSize = 11.sp)
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        Text("Assigned Site Visits", color = NeutralWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Spacer(modifier = Modifier.height(8.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(bookings) { booking ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = CharcoalCard),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CharcoalBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(booking.serviceType.title, color = NeutralWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Surface(shape = RoundedCornerShape(6.dp), color = StatusBlueBg) {
                                Text(booking.status.displayName, color = StatusBlue, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Customer: ${booking.customerName} (${booking.customerPhone})", color = SafetyOrangeLight, fontSize = 12.sp)
                        Text("Site Location: ${booking.siteAddress}", color = NeutralGray200, fontSize = 11.sp)
                        Text("Scope: ${booking.equipmentType} (${booking.estimatedUnits} units)", color = NeutralGray400, fontSize = 11.sp)

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            if (booking.status != BookingStatus.IN_PROGRESS && booking.status != BookingStatus.COMPLETED) {
                                Button(
                                    onClick = {
                                        onUpdateStatus(booking.id, BookingStatus.IN_PROGRESS, "Technician reached customer site. Pressure testing underway.")
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = SafetyOrange),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Start Work at Site", color = CharcoalBlack, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            if (booking.status == BookingStatus.IN_PROGRESS) {
                                Button(
                                    onClick = {
                                        onUpdateStatus(booking.id, BookingStatus.COMPLETED, "Hydrostatic testing verified. All cylinders refilled, certified and tagged.")
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = StatusGreen),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Complete & Tag", color = NeutralWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
