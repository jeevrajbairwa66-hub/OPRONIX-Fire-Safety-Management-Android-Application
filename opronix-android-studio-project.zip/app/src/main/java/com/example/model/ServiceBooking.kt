package com.example.model

enum class ServiceType(val title: String, val hindiTitle: String, val baseFee: Double, val iconName: String) {
    EXTINGUISHER_REFILLING("Fire Extinguisher Refilling", "अग्निशामक रीफिलिंग", 450.0, "refresh"),
    EXTINGUISHER_INSPECTION("Extinguisher Hydro-Testing & Inspection", "अग्निशामक निरीक्षण", 350.0, "fact_check"),
    ALARM_INSTALLATION("Fire Alarm Panel Installation", "फायर अलार्म इंस्टॉलेशन", 2500.0, "settings_input_component"),
    SMOKE_DETECTOR_INSTALLATION("Smoke Detector Setup & Wiring", "धुआं डिटेक्टर इंस्टॉलेशन", 1200.0, "sensors"),
    HYDRANT_INSTALLATION("Fire Hydrant System Installation", "हाइड्रेंट सिस्टम स्थापना", 5000.0, "plumbing"),
    SPRINKLER_INSTALLATION("Automatic Sprinkler Installation", "स्प्रिंकलर सिस्टम स्थापना", 4500.0, "grain"),
    EQUIPMENT_MAINTENANCE("Routine Equipment Maintenance", "उपकरण नियमित रखरखाव", 800.0, "build"),
    FIRE_SAFETY_AUDIT("Comprehensive Fire Safety Audit", "फायर सेफ्टी ऑडिट", 3500.0, "verified_user"),
    SAFETY_TRAINING("Fire Drill & Safety Training Inquiry", "सुरक्षा प्रशिक्षण व मॉकड्रिल", 4000.0, "groups"),
    COMMERCIAL_CONSULTATION("Commercial Protection Consultation", "वाणिज्यिक सुरक्षा परामर्श", 1500.0, "business")
}

enum class PropertyType(val label: String) {
    COMMERCIAL_OFFICE("Commercial Office"),
    INDUSTRIAL_FACTORY("Industrial Factory / Manufacturing"),
    WAREHOUSE_LOGISTICS("Warehouse & Logistics Hub"),
    RESIDENTIAL_APARTMENT("Residential Society / High-Rise"),
    HOSPITAL_HEALTHCARE("Hospital & Healthcare Facility"),
    HOTEL_RESTAURANT("Hotel / Restaurant / Mall"),
    EDUCATIONAL_INSTITUTION("School / College / University")
}

enum class BookingStatus(val displayName: String, val hindiName: String) {
    PENDING("Booking Received", "अनुरोध प्राप्त हुआ"),
    CONFIRMED("Confirmed", "पुष्टि हो गई"),
    TECHNICIAN_ASSIGNED("Technician Assigned", "तकनीशियन नियुक्त"),
    IN_PROGRESS("In Progress / At Site", "साइट पर कार्य प्रगति पर"),
    COMPLETED("Completed & Verified", "पूर्ण एवं सत्यापित"),
    CANCELLED("Cancelled", "रद्द किया गया")
}

data class ServiceBooking(
    val id: String,
    val bookingNumber: String,
    val serviceType: ServiceType,
    val customerId: String,
    val customerName: String,
    val customerPhone: String,
    val siteAddress: String,
    val propertyType: PropertyType,
    val preferredDate: String,
    val preferredTimeSlot: String,
    val equipmentType: String,
    val estimatedUnits: Int,
    val problemDescription: String,
    val photoReference: String? = null,
    val status: BookingStatus = BookingStatus.PENDING,
    val assignedTechnicianId: String? = null,
    val assignedTechnicianName: String? = null,
    val assignedTechnicianPhone: String? = null,
    val estimatedCost: Double = 0.0,
    val technicianNotes: String = "",
    val completionTimestampMillis: Long? = null,
    val createdAtMillis: Long = System.currentTimeMillis(),
    val isDemoBooking: Boolean = true
) {
    val formattedCost: String
        get() = if (estimatedCost > 0) "₹%,.0f".format(estimatedCost) else "Pending Site Assessment"
}
