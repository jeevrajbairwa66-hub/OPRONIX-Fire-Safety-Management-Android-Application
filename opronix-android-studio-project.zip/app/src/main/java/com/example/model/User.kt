package com.example.model

enum class UserRole {
    CUSTOMER,
    TECHNICIAN,
    ADMIN
}

enum class AppLanguage(val code: String, val label: String) {
    ENGLISH("en", "English"),
    HINDI("hi", "हिन्दी")
}

data class User(
    val id: String = "usr_demo_1",
    val name: String = "Rajesh Sharma",
    val email: String = "rajesh.sharma@example.com",
    val phone: String = "+91 98290 12345",
    val role: UserRole = UserRole.CUSTOMER,
    val companyName: String = "Sharma Enterprises Pvt Ltd",
    val gstNumber: String = "08AAAAA0000A1Z5",
    val addresses: List<Address> = listOf(
        Address(
            id = "addr_1",
            label = "Corporate Office",
            street = "Plot 42, Sitapura Industrial Area",
            city = "Jaipur",
            state = "Rajasthan",
            pincode = "302022",
            isDefault = true
        ),
        Address(
            id = "addr_2",
            label = "Warehouse Facility",
            street = "Sector 14, Transport Nagar",
            city = "Jaipur",
            state = "Rajasthan",
            pincode = "302003",
            isDefault = false
        )
    )
)

data class Address(
    val id: String = "",
    val label: String = "Work",
    val street: String = "",
    val city: String = "",
    val state: String = "Rajasthan",
    val pincode: String = "",
    val isDefault: Boolean = false
) {
    val formatted: String
        get() = "$street, $city, $state - $pincode"
}
