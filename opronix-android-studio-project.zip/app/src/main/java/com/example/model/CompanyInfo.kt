package com.example.model

data class CompanyInfo(
    val companyName: String = "OPRONIX Fire Safety Solutions",
    val registrationNumber: String = "CIN: U29309RJ2021PTC074211",
    val gstNumber: String = "08AAKCO1234F1Z8",
    val primaryHelpline: String = "+91 98290 88888",
    val supportEmail: String = "contact@opronix.in",
    val salesEmail: String = "sales@opronix.in",
    val whatsAppNumber: String = "919829088888",
    val headOfficeAddress: String = "Plot No. E-42, Sitapura Industrial Area, Phase II, Jaipur, Rajasthan 302022",
    val workingHours: String = "Monday - Saturday: 9:00 AM - 7:30 PM",
    val activeServiceHubs: List<String> = listOf(
        "Jaipur", "Delhi NCR", "Gurugram", "Noida", "Mumbai", "Ahmedabad", "Pune", "Bengaluru"
    ),
    val nationalFireEmergencyNumber: String = "101",
    val nationalEmergencyNumber: String = "112",
    val emergencyDisclaimer: String = "CRITICAL SAFETY NOTICE: For active fires or life hazards, dial 101 (Fire Brigade) or 112 (Emergency Response) immediately. OPRONIX is a commercial equipment and maintenance service and does NOT replace government emergency services."
)

enum class NotificationType {
    ORDER,
    SERVICE,
    QUOTATION,
    AMC_RENEWAL,
    ANNOUNCEMENT
}

data class NotificationItem(
    val id: String,
    val title: String,
    val hindiTitle: String = "",
    val message: String,
    val hindiMessage: String = "",
    val timestampMillis: Long,
    val type: NotificationType,
    val isRead: Boolean = false,
    val referenceId: String? = null
)
