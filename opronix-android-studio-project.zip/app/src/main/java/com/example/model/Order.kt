package com.example.model

enum class OrderStatus(val displayName: String, val hindiName: String) {
    PENDING("Order Placed", "ऑर्डर दिया गया"),
    CONFIRMED("Confirmed", "स्वीकृत"),
    PROCESSING("Processing", "प्रक्रियाधीन"),
    SHIPPED("Shipped", "भेज दिया गया"),
    DELIVERED("Delivered", "वितरित"),
    CANCELLED("Cancelled", "रद्द किया गया")
}

enum class PaymentMethod(val displayName: String, val isCod: Boolean) {
    CASH_ON_DELIVERY("Cash on Delivery (Admin verified)", true),
    PAY_ON_INVOICE("Official Corporate Invoice (NEFT/RTGS)", false),
    ONLINE_UPI_GATEWAY("Online UPI / Card (Demo Gateway Hook)", false)
}

enum class PaymentStatus {
    PENDING,
    PAID,
    DEMO_VERIFIED
}

data class CartItem(
    val product: Product,
    val quantity: Int = 1
) {
    val totalItemPrice: Double
        get() = product.price * quantity

    val formattedItemPrice: String
        get() = "₹%,.0f".format(totalItemPrice)
}

data class CartSummary(
    val items: List<CartItem>,
    val couponDiscount: Double = 0.0,
    val deliveryFee: Double = if (items.isNotEmpty()) 250.0 else 0.0
) {
    val subtotal: Double
        get() = items.sumOf { it.totalItemPrice }

    val gstAmount: Double
        get() = (subtotal - couponDiscount).coerceAtLeast(0.0) * 0.18 // 18% standard GST for safety equipment

    val grandTotal: Double
        get() = (subtotal - couponDiscount).coerceAtLeast(0.0) + gstAmount + deliveryFee

    val totalItemCount: Int
        get() = items.sumOf { it.quantity }
}

data class Order(
    val id: String,
    val invoiceNumber: String,
    val customerId: String,
    val customerName: String,
    val customerPhone: String,
    val orderDateMillis: Long = System.currentTimeMillis(),
    val items: List<CartItem>,
    val subtotal: Double,
    val gstAmount: Double,
    val deliveryFee: Double,
    val discount: Double,
    val totalAmount: Double,
    val deliveryAddress: Address,
    val status: OrderStatus = OrderStatus.PENDING,
    val paymentMethod: PaymentMethod = PaymentMethod.PAY_ON_INVOICE,
    val paymentStatus: PaymentStatus = PaymentStatus.PENDING,
    val trackingNotes: List<TrackingUpdate> = listOf(
        TrackingUpdate("Order placed successfully via OPRONIX", System.currentTimeMillis())
    ),
    val isDemoOrder: Boolean = true
) {
    val formattedTotal: String
        get() = "₹%,.0f".format(totalAmount)
}

data class TrackingUpdate(
    val message: String,
    val timestampMillis: Long
)
