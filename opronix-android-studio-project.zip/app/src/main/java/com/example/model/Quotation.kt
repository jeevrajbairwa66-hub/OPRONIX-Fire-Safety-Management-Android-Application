package com.example.model

enum class QuotationStatus(val displayName: String, val hindiName: String) {
    REQUESTED("Quotation Requested", "कोटेशन अनुरोध भेजा गया"),
    UNDER_REVIEW("Under Review by Estimator", "मूल्यांकन जारी"),
    QUOTATION_PREPARED("Official Quote Ready", "आधिकारिक कोटेशन तैयार"),
    ACCEPTED("Accepted by Customer", "ग्राहक द्वारा स्वीकृत"),
    REJECTED("Declined", "अस्वीकृत")
}

data class QuotationItem(
    val title: String,
    val description: String,
    val quantity: Int,
    val estimatedUnitPrice: Double = 0.0
)

data class Quotation(
    val id: String,
    val quoteReference: String,
    val customerId: String,
    val customerName: String,
    val companyName: String,
    val email: String,
    val phone: String,
    val siteAddress: String,
    val requirements: String,
    val requestedItems: List<QuotationItem> = emptyList(),
    val status: QuotationStatus = QuotationStatus.REQUESTED,
    val quotedSubtotal: Double? = null,
    val quotedGst: Double? = null,
    val quotedGrandTotal: Double? = null,
    val validityDays: Int = 30,
    val termsAndConditions: String = "1. Price includes supply & testing.\n2. Delivery within 7 working days.\n3. GST 18% extra as applicable.",
    val adminNotes: String = "",
    val requestDateMillis: Long = System.currentTimeMillis(),
    val isDemoQuote: Boolean = true
) {
    val formattedQuotedTotal: String?
        get() = quotedGrandTotal?.let { "₹%,.0f".format(it) }
}
