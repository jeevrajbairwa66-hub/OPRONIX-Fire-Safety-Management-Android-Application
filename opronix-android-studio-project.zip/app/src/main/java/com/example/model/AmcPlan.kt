package com.example.model

enum class AmcTier(val title: String, val hindiTitle: String, val annualPrice: Double) {
    ESSENTIAL("Essential Protection AMC", "आवश्यक सुरक्षा एएमसी", 8999.0),
    COMMERCIAL_PRO("Commercial Pro AMC", "व्यावसायिक प्रो एएमसी", 24999.0),
    INDUSTRIAL_ENTERPRISE("Industrial Enterprise AMC", "औद्योगिक एंटरप्राइज एएमसी", 59999.0)
}

enum class AmcStatus(val label: String) {
    ACTIVE("Active Contract"),
    EXPIRING_SOON("Expiring in 30 Days"),
    EXPIRED("Expired - Needs Renewal"),
    PENDING_APPROVAL("Pending Contract Signing")
}

data class AmcContract(
    val id: String,
    val contractNumber: String,
    val customerId: String,
    val customerName: String,
    val companyName: String,
    val tier: AmcTier,
    val siteAddress: String,
    val coveredEquipmentsCount: Int,
    val quarterlyAuditsDone: Int = 1,
    val totalQuarterlyAudits: Int = 4,
    val startDate: String,
    val renewalDate: String,
    val annualFee: Double,
    val status: AmcStatus = AmcStatus.ACTIVE,
    val includesFreeRefilling: Boolean = true,
    val includesEmergencyResponse: Boolean = true,
    val nextScheduledAuditDate: String = "15 Nov 2026"
) {
    val formattedFee: String
        get() = "₹%,.0f/year".format(annualFee)
}
