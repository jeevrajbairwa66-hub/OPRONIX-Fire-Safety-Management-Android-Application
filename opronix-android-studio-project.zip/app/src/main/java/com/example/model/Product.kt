package com.example.model

enum class ProductCategory(val displayName: String, val hindiName: String, val iconName: String) {
    ABC_EXTINGUISHER("ABC Fire Extinguishers", "एबीसी अग्निशामक", "fire_extinguisher"),
    CO2_EXTINGUISHER("CO2 Fire Extinguishers", "CO2 अग्निशामक", "co2"),
    FOAM_EXTINGUISHER("Foam Fire Extinguishers", "फोम अग्निशामक", "water_drop"),
    WATER_EXTINGUISHER("Water Fire Extinguishers", "पानी अग्निशामक", "waves"),
    SMOKE_DETECTOR("Smoke Detectors", "धुआं डिटेक्टर", "sensors"),
    HEAT_DETECTOR("Heat Detectors", "ताप डिटेक्टर", "thermostat"),
    ALARM_PANEL("Fire Alarm Panels", "फायर अलार्म पैनल", "dashboard"),
    ALARM_HOOTER("Fire Alarm Hooters", "अलार्म हूटर्स", "volume_up"),
    SPRINKLER_SYSTEM("Sprinkler Systems", "स्प्रिंकलर सिस्टम", "grain"),
    HOSE_REEL("Fire Hose Reels", "फायर होज़ रील्स", "cyclone"),
    HYDRANT_EQUIPMENT("Hydrant Equipment", "हाइड्रेंट उपकरण", "plumbing"),
    SAFETY_SIGNAGE("Fire Safety Signage", "सुरक्षा संकेत", "warning"),
    EMERGENCY_LIGHT("Emergency Lights", "आपातकालीन लाइट्स", "lightbulb"),
    FIRE_BLANKET("Fire Blankets", "फायर ब्लैंकेट", "layers"),
    ACCESSORIES("Safety Accessories", "सुरक्षा सहायक उपकरण", "build")
}

data class Product(
    val id: String,
    val name: String,
    val hindiName: String = "",
    val category: ProductCategory,
    val price: Double,
    val originalPrice: Double? = null,
    val capacity: String = "Standard",
    val description: String = "Certified fire safety equipment conforming to IS standards.",
    val specifications: Map<String, String> = emptyMap(),
    val stockQuantity: Int = 25,
    val inStock: Boolean = true,
    val rating: Float = 4.8f,
    val reviewCount: Int = 34,
    val isDemo: Boolean = true,
    val warrantyText: String = "1 Year Manufacturer Warranty (Standard)",
    val standardCompliance: String = "IS 15683 / BIS Certified Standard",
    val imageDrawableRes: Int? = null,
    val imageUrl: String = "",
    val isFeatured: Boolean = false,
    val isFavorite: Boolean = false
) {
    val formattedPrice: String
        get() = "₹%,.0f".format(price)

    val formattedOriginalPrice: String?
        get() = originalPrice?.let { "₹%,.0f".format(it) }

    val discountPercentage: Int?
        get() = originalPrice?.let {
            if (it > price) (((it - price) / it) * 100).toInt() else null
        }
}
