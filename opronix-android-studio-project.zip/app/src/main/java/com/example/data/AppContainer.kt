package com.example.data

import android.content.Context
import com.example.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class AppContainer(private val context: Context) {

    val demoRepository = DemoRepository()
    val firebaseRepository = FirebaseRepository(context, demoRepository)

    // Default to demo repository for reliable offline testing as requested
    val authRepository: IAuthRepository = demoRepository
    val productRepository: IProductRepository = demoRepository
    val orderRepository: IOrderRepository = demoRepository
    val serviceRepository: IServiceRepository = demoRepository
    val quotationRepository: IQuotationRepository = demoRepository
    val amcRepository: IAmcRepository = demoRepository
    val notificationRepository: INotificationRepository = demoRepository

    val companyInfo = CompanyInfo()

    // App Language state
    private val _language = MutableStateFlow(AppLanguage.ENGLISH)
    val language: StateFlow<AppLanguage> = _language.asStateFlow()

    fun setLanguage(lang: AppLanguage) {
        _language.value = lang
    }

    // Cart State
    private val _cartItems = MutableStateFlow<List<CartItem>>(emptyList())
    val cartItems: StateFlow<List<CartItem>> = _cartItems.asStateFlow()

    private val _appliedCoupon = MutableStateFlow<String?>(null)
    val appliedCoupon: StateFlow<String?> = _appliedCoupon.asStateFlow()

    private val _couponDiscount = MutableStateFlow(0.0)
    val couponDiscount: StateFlow<Double> = _couponDiscount.asStateFlow()

    fun addToCart(product: Product, quantity: Int = 1) {
        _cartItems.update { current ->
            val existingIndex = current.indexOfFirst { it.product.id == product.id }
            if (existingIndex >= 0) {
                current.toMutableList().apply {
                    val existing = this[existingIndex]
                    this[existingIndex] = existing.copy(quantity = existing.quantity + quantity)
                }
            } else {
                current + CartItem(product = product, quantity = quantity)
            }
        }
    }

    fun updateCartQuantity(productId: String, newQuantity: Int) {
        if (newQuantity <= 0) {
            removeFromCart(productId)
            return
        }
        _cartItems.update { current ->
            current.map {
                if (it.product.id == productId) it.copy(quantity = newQuantity) else it
            }
        }
    }

    fun removeFromCart(productId: String) {
        _cartItems.update { current ->
            current.filterNot { it.product.id == productId }
        }
    }

    fun clearCart() {
        _cartItems.value = emptyList()
        _appliedCoupon.value = null
        _couponDiscount.value = 0.0
    }

    fun applyCoupon(code: String): Boolean {
        return if (code.trim().equals("FIRESAFE10", ignoreCase = true)) {
            val subtotal = _cartItems.value.sumOf { it.totalItemPrice }
            val discount = (subtotal * 0.10).coerceAtMost(2000.0)
            _appliedCoupon.value = "FIRESAFE10"
            _couponDiscount.value = discount
            true
        } else false
    }

    fun removeCoupon() {
        _appliedCoupon.value = null
        _couponDiscount.value = 0.0
    }
}
