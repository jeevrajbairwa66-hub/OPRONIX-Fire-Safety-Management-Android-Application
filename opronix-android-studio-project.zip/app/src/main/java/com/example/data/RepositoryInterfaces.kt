package com.example.data

import com.example.model.*
import kotlinx.coroutines.flow.Flow

interface IAuthRepository {
    val currentUser: Flow<User?>
    suspend fun login(email: String, pass: String): Result<User>
    suspend fun register(name: String, email: String, phone: String, pass: String): Result<User>
    suspend fun logout()
    suspend fun switchRole(role: UserRole)
    suspend fun updateProfile(name: String, phone: String, company: String, gst: String): Result<Unit>
    suspend fun addAddress(address: Address): Result<Unit>
}

interface IProductRepository {
    val products: Flow<List<Product>>
    suspend fun getProductById(id: String): Product?
    suspend fun addProduct(product: Product): Result<Product>
    suspend fun updateProduct(product: Product): Result<Unit>
    suspend fun deleteProduct(id: String): Result<Unit>
    suspend fun toggleFavorite(id: String)
}

interface IOrderRepository {
    val orders: Flow<List<Order>>
    suspend fun getOrderById(id: String): Order?
    suspend fun placeOrder(
        items: List<CartItem>,
        deliveryAddress: Address,
        paymentMethod: PaymentMethod,
        discount: Double
    ): Result<Order>
    suspend fun updateOrderStatus(orderId: String, newStatus: OrderStatus, note: String = ""): Result<Unit>
}

interface IServiceRepository {
    val bookings: Flow<List<ServiceBooking>>
    suspend fun getBookingById(id: String): ServiceBooking?
    suspend fun requestBooking(booking: ServiceBooking): Result<ServiceBooking>
    suspend fun updateBookingStatus(bookingId: String, status: BookingStatus, notes: String = ""): Result<Unit>
    suspend fun assignTechnician(bookingId: String, techId: String, techName: String, techPhone: String): Result<Unit>
}

interface IQuotationRepository {
    val quotations: Flow<List<Quotation>>
    suspend fun getQuotationById(id: String): Quotation?
    suspend fun submitQuotationRequest(quotation: Quotation): Result<Quotation>
    suspend fun updateQuotation(
        quoteId: String,
        status: QuotationStatus,
        subtotal: Double?,
        gst: Double?,
        grandTotal: Double?,
        adminNotes: String
    ): Result<Unit>
}

interface IAmcRepository {
    val contracts: Flow<List<AmcContract>>
    suspend fun submitAmcInquiry(
        customerId: String,
        customerName: String,
        companyName: String,
        tier: AmcTier,
        siteAddress: String,
        equipmentCount: Int
    ): Result<AmcContract>
}

interface INotificationRepository {
    val notifications: Flow<List<NotificationItem>>
    suspend fun markAsRead(id: String)
    suspend fun addNotification(item: NotificationItem)
}
