package com.example.data

import android.content.Context
import android.util.Log
import com.example.model.*
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Switchable Firebase Repository implementation.
 * Connects to Firebase Authentication & Cloud Firestore when google-services.json is configured,
 * while safely guarding runtime calls to avoid crashes when running in offline/demo mode.
 */
class FirebaseRepository(private val context: Context, private val fallbackDemo: DemoRepository) :
    IAuthRepository by fallbackDemo,
    IProductRepository by fallbackDemo,
    IOrderRepository by fallbackDemo,
    IServiceRepository by fallbackDemo,
    IQuotationRepository by fallbackDemo,
    IAmcRepository by fallbackDemo,
    INotificationRepository by fallbackDemo {

    companion object {
        private const val TAG = "FirebaseRepository"
    }

    private var isFirebaseAvailable: Boolean = false
    private var auth: FirebaseAuth? = null
    private var firestore: FirebaseFirestore? = null

    private val _isLiveConnected = MutableStateFlow(false)
    val isLiveConnected: Flow<Boolean> = _isLiveConnected.asStateFlow()

    init {
        try {
            val app = FirebaseApp.initializeApp(context)
            if (app != null) {
                auth = FirebaseAuth.getInstance()
                firestore = FirebaseFirestore.getInstance()
                isFirebaseAvailable = true
                _isLiveConnected.value = true
                Log.d(TAG, "Firebase initialized successfully with project: ${app.options.projectId}")
            }
        } catch (e: Exception) {
            Log.w(TAG, "Firebase not provisioned yet; operating smoothly in Demo Mode: ${e.message}")
            isFirebaseAvailable = false
            _isLiveConnected.value = false
        }
    }

    fun isConfigured(): Boolean = isFirebaseAvailable
}
