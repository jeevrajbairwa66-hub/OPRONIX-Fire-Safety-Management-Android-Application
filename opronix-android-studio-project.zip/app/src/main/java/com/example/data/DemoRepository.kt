package com.example.data

import com.example.model.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class DemoRepository :
    IAuthRepository,
    IProductRepository,
    IOrderRepository,
    IServiceRepository,
    IQuotationRepository,
    IAmcRepository,
    INotificationRepository {

    // Current User
    private val _currentUser = MutableStateFlow<User?>(
        User(
            id = "usr_demo_1",
            name = "Rajesh Sharma",
            email = "rajesh.sharma@example.com",
            phone = "+91 98290 12345",
            role = UserRole.CUSTOMER,
            companyName = "Sharma Enterprises Pvt Ltd",
            gstNumber = "08AAAAA0000A1Z5"
        )
    )
    override val currentUser: Flow<User?> = _currentUser.asStateFlow()

    // Products State
    private val _products = MutableStateFlow<List<Product>>(createInitialProducts())
    override val products: Flow<List<Product>> = _products.asStateFlow()

    // Orders State
    private val _orders = MutableStateFlow<List<Order>>(createInitialOrders())
    override val orders: Flow<List<Order>> = _orders.asStateFlow()

    // Service Bookings State
    private val _bookings = MutableStateFlow<List<ServiceBooking>>(createInitialBookings())
    override val bookings: Flow<List<ServiceBooking>> = _bookings.asStateFlow()

    // Quotations State
    private val _quotations = MutableStateFlow<List<Quotation>>(createInitialQuotations())
    override val quotations: Flow<List<Quotation>> = _quotations.asStateFlow()

    // AMC Contracts State
    private val _contracts = MutableStateFlow<List<AmcContract>>(createInitialContracts())
    override val contracts: Flow<List<AmcContract>> = _contracts.asStateFlow()

    // Notifications State
    private val _notifications = MutableStateFlow<List<NotificationItem>>(createInitialNotifications())
    override val notifications: Flow<List<NotificationItem>> = _notifications.asStateFlow()

    // --- Auth Repository Implementation ---
    override suspend fun login(email: String, pass: String): Result<User> {
        val user = _currentUser.value?.copy(email = email) ?: User(email = email)
        _currentUser.value = user
        return Result.success(user)
    }

    override suspend fun register(name: String, email: String, phone: String, pass: String): Result<User> {
        val user = User(
            id = "usr_" + UUID.randomUUID().toString().take(8),
            name = name,
            email = email,
            phone = phone,
            role = UserRole.CUSTOMER
        )
        _currentUser.value = user
        return Result.success(user)
    }

    override suspend fun logout() {
        _currentUser.value = null
    }

    override suspend fun switchRole(role: UserRole) {
        _currentUser.update { current ->
            (current ?: User()).copy(
                role = role,
                name = when (role) {
                    UserRole.CUSTOMER -> "Rajesh Sharma (Customer)"
                    UserRole.TECHNICIAN -> "Vikram Singh (Sr. Field Technician)"
                    UserRole.ADMIN -> "Admin Portal (OPRONIX Manager)"
                }
            )
        }
    }

    override suspend fun updateProfile(name: String, phone: String, company: String, gst: String): Result<Unit> {
        _currentUser.update { current ->
            current?.copy(name = name, phone = phone, companyName = company, gstNumber = gst)
        }
        return Result.success(Unit)
    }

    override suspend fun addAddress(address: Address): Result<Unit> {
        _currentUser.update { current ->
            current?.copy(addresses = current.addresses + address)
        }
        return Result.success(Unit)
    }

    // --- Product Repository Implementation ---
    override suspend fun getProductById(id: String): Product? {
        return _products.value.find { it.id == id }
    }

    override suspend fun addProduct(product: Product): Result<Product> {
        _products.update { listOf(product) + it }
        return Result.success(product)
    }

    override suspend fun updateProduct(product: Product): Result<Unit> {
        _products.update { list ->
            list.map { if (it.id == product.id) product else it }
        }
        return Result.success(Unit)
    }

    override suspend fun deleteProduct(id: String): Result<Unit> {
        _products.update { list -> list.filterNot { it.id == id } }
        return Result.success(Unit)
    }

    override suspend fun toggleFavorite(id: String) {
        _products.update { list ->
            list.map { if (it.id == id) it.copy(isFavorite = !it.isFavorite) else it }
        }
    }

    // --- Order Repository Implementation ---
    override suspend fun getOrderById(id: String): Order? {
        return _orders.value.find { it.id == id }
    }

    override suspend fun placeOrder(
        items: List<CartItem>,
        deliveryAddress: Address,
        paymentMethod: PaymentMethod,
        discount: Double
    ): Result<Order> {
        val subtotal = items.sumOf { it.totalItemPrice }
        val gst = (subtotal - discount).coerceAtLeast(0.0) * 0.18
        val delivery = 250.0
        val grandTotal = (subtotal - discount).coerceAtLeast(0.0) + gst + delivery
        val code = (1000..9999).random()

        val newOrder = Order(
            id = "ORD-2026-$code",
            invoiceNumber = "OPR-INV-$code",
            customerId = _currentUser.value?.id ?: "usr_guest",
            customerName = _currentUser.value?.name ?: "Customer",
            customerPhone = _currentUser.value?.phone ?: "+91 98000 00000",
            orderDateMillis = System.currentTimeMillis(),
            items = items,
            subtotal = subtotal,
            gstAmount = gst,
            deliveryFee = delivery,
            discount = discount,
            totalAmount = grandTotal,
            deliveryAddress = deliveryAddress,
            status = OrderStatus.PENDING,
            paymentMethod = paymentMethod,
            paymentStatus = if (paymentMethod.isCod) PaymentStatus.PENDING else PaymentStatus.DEMO_VERIFIED,
            isDemoOrder = true
        )

        _orders.update { listOf(newOrder) + it }

        addNotification(
            NotificationItem(
                id = UUID.randomUUID().toString(),
                title = "Order Placed Successfully",
                hindiTitle = "ऑर्डर सफलतापूर्वक दर्ज",
                message = "Your order #${newOrder.id} for ₹%,.0f has been received.".format(grandTotal),
                timestampMillis = System.currentTimeMillis(),
                type = NotificationType.ORDER,
                referenceId = newOrder.id
            )
        )

        return Result.success(newOrder)
    }

    override suspend fun updateOrderStatus(orderId: String, newStatus: OrderStatus, note: String): Result<Unit> {
        _orders.update { list ->
            list.map { order ->
                if (order.id == orderId) {
                    val updateMsg = if (note.isNotBlank()) note else "Status updated to ${newStatus.displayName}"
                    val newHistory = order.trackingNotes + TrackingUpdate(updateMsg, System.currentTimeMillis())
                    order.copy(status = newStatus, trackingNotes = newHistory)
                } else order
            }
        }
        return Result.success(Unit)
    }

    // --- Service Repository Implementation ---
    override suspend fun getBookingById(id: String): ServiceBooking? {
        return _bookings.value.find { it.id == id }
    }

    override suspend fun requestBooking(booking: ServiceBooking): Result<ServiceBooking> {
        _bookings.update { listOf(booking) + it }
        addNotification(
            NotificationItem(
                id = UUID.randomUUID().toString(),
                title = "Service Booking Registered",
                hindiTitle = "सर्विस बुकिंग दर्ज",
                message = "Your request for ${booking.serviceType.title} (#${booking.bookingNumber}) is under review.",
                timestampMillis = System.currentTimeMillis(),
                type = NotificationType.SERVICE,
                referenceId = booking.id
            )
        )
        return Result.success(booking)
    }

    override suspend fun updateBookingStatus(bookingId: String, status: BookingStatus, notes: String): Result<Unit> {
        _bookings.update { list ->
            list.map { b ->
                if (b.id == bookingId) {
                    b.copy(
                        status = status,
                        technicianNotes = if (notes.isNotBlank()) notes else b.technicianNotes,
                        completionTimestampMillis = if (status == BookingStatus.COMPLETED) System.currentTimeMillis() else b.completionTimestampMillis
                    )
                } else b
            }
        }
        return Result.success(Unit)
    }

    override suspend fun assignTechnician(
        bookingId: String,
        techId: String,
        techName: String,
        techPhone: String
    ): Result<Unit> {
        _bookings.update { list ->
            list.map { b ->
                if (b.id == bookingId) {
                    b.copy(
                        status = BookingStatus.TECHNICIAN_ASSIGNED,
                        assignedTechnicianId = techId,
                        assignedTechnicianName = techName,
                        assignedTechnicianPhone = techPhone
                    )
                } else b
            }
        }
        return Result.success(Unit)
    }

    // --- Quotation Repository Implementation ---
    override suspend fun getQuotationById(id: String): Quotation? {
        return _quotations.value.find { it.id == id }
    }

    override suspend fun submitQuotationRequest(quotation: Quotation): Result<Quotation> {
        _quotations.update { listOf(quotation) + it }
        addNotification(
            NotificationItem(
                id = UUID.randomUUID().toString(),
                title = "Quotation Request Submitted",
                hindiTitle = "कोटेशन अनुरोध जमा",
                message = "Ref #${quotation.quoteReference} is being processed by OPRONIX estimators.",
                timestampMillis = System.currentTimeMillis(),
                type = NotificationType.QUOTATION,
                referenceId = quotation.id
            )
        )
        return Result.success(quotation)
    }

    override suspend fun updateQuotation(
        quoteId: String,
        status: QuotationStatus,
        subtotal: Double?,
        gst: Double?,
        grandTotal: Double?,
        adminNotes: String
    ): Result<Unit> {
        _quotations.update { list ->
            list.map { q ->
                if (q.id == quoteId) {
                    q.copy(
                        status = status,
                        quotedSubtotal = subtotal,
                        quotedGst = gst,
                        quotedGrandTotal = grandTotal,
                        adminNotes = adminNotes
                    )
                } else q
            }
        }
        return Result.success(Unit)
    }

    // --- AMC Repository Implementation ---
    override suspend fun submitAmcInquiry(
        customerId: String,
        customerName: String,
        companyName: String,
        tier: AmcTier,
        siteAddress: String,
        equipmentCount: Int
    ): Result<AmcContract> {
        val code = (1000..9999).random()
        val contract = AmcContract(
            id = "AMC-2026-$code",
            contractNumber = "OPR-AMC-$code",
            customerId = customerId,
            customerName = customerName,
            companyName = companyName,
            tier = tier,
            siteAddress = siteAddress,
            coveredEquipmentsCount = equipmentCount,
            startDate = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date()),
            renewalDate = "26 Oct 2027",
            annualFee = tier.annualPrice,
            status = AmcStatus.ACTIVE
        )
        _contracts.update { listOf(contract) + it }
        addNotification(
            NotificationItem(
                id = UUID.randomUUID().toString(),
                title = "New AMC Contract Activated",
                hindiTitle = "नया एएमसी अनुबंध सक्रिय",
                message = "Your ${tier.title} contract #${contract.contractNumber} has been recorded.",
                timestampMillis = System.currentTimeMillis(),
                type = NotificationType.AMC_RENEWAL,
                referenceId = contract.id
            )
        )
        return Result.success(contract)
    }

    // --- Notification Repository Implementation ---
    override suspend fun markAsRead(id: String) {
        _notifications.update { list ->
            list.map { if (it.id == id) it.copy(isRead = true) else it }
        }
    }

    override suspend fun addNotification(item: NotificationItem) {
        _notifications.update { listOf(item) + it }
    }

    // --- Realistic Seed Data Generator ---
    private fun createInitialProducts(): List<Product> = listOf(
        // ABC Extinguishers
        Product(
            id = "prod_abc_4kg",
            name = "OPRONIX Pro ABC Powder Fire Extinguisher (4 kg)",
            hindiName = "ओप्रोनिक्स प्रो एबीसी पाउडर अग्निशामक (4 किग्रा)",
            category = ProductCategory.ABC_EXTINGUISHER,
            price = 1850.0,
            originalPrice = 2400.0,
            capacity = "4 kg Stored Pressure",
            description = "High efficiency mono ammonium phosphate powder suitable for Class A, B, and C fires. Certified to IS 15683 with pressure gauge and heavy-duty brass valve.",
            specifications = mapOf(
                "Extinguishing Medium" to "Mono Ammonium Phosphate (MAP 50%)",
                "Working Pressure" to "15 bar",
                "Discharge Time" to "> 13 seconds",
                "Operating Temperature" to "-30°C to +55°C",
                "Fire Rating" to "2A : 21B"
            ),
            stockQuantity = 45,
            isFeatured = true,
            isFavorite = true
        ),
        Product(
            id = "prod_abc_6kg",
            name = "OPRONIX Industrial ABC Dry Powder Extinguisher (6 kg)",
            hindiName = "ओप्रोनिक्स इंडस्ट्रियल एबीसी पाउडर अग्निशामक (6 किग्रा)",
            category = ProductCategory.ABC_EXTINGUISHER,
            price = 2650.0,
            originalPrice = 3300.0,
            capacity = "6 kg Stored Pressure",
            description = "Ideal for factories, warehouses, and commercial basements. High discharge throw with reinforced hose assembly.",
            specifications = mapOf(
                "Extinguishing Medium" to "MAP 90% High Grade Powder",
                "Fire Rating" to "3A : 34B",
                "Discharge Duration" to "15 - 18 seconds",
                "Test Pressure" to "35 bar"
            ),
            stockQuantity = 32,
            isFeatured = true
        ),
        Product(
            id = "prod_abc_2kg",
            name = "OPRONIX Compact Car & Home ABC Extinguisher (2 kg)",
            hindiName = "ओप्रोनिक्स कॉम्पैक्ट कार एवं होम एबीसी अग्निशामक (2 किग्रा)",
            category = ProductCategory.ABC_EXTINGUISHER,
            price = 1150.0,
            originalPrice = 1450.0,
            capacity = "2 kg Compact",
            description = "Compact safety unit designed for vehicles, server racks, and residential kitchens with sturdy mounting bracket.",
            specifications = mapOf(
                "Capacity" to "2 kg",
                "Fire Rating" to "1A : 8B",
                "Weight" to "3.4 kg gross"
            ),
            stockQuantity = 60
        ),

        // CO2 Extinguishers
        Product(
            id = "prod_co2_2kg",
            name = "OPRONIX Clean Agent CO2 Fire Extinguisher (2 kg)",
            hindiName = "ओप्रोनिक्स क्लीन एजेंट CO2 अग्निशामक (2 किग्रा)",
            category = ProductCategory.CO2_EXTINGUISHER,
            price = 3450.0,
            originalPrice = 4200.0,
            capacity = "2 kg High Pressure Seamless",
            description = "Residue-free carbon dioxide extinguisher specially engineered for electrical switchboards, server rooms, and medical laboratories.",
            specifications = mapOf(
                "Cylinder Material" to "Seamless Manganese Steel (IS 7285)",
                "Fire Rating" to "8B",
                "Operating Pressure" to "56 bar at 20°C"
            ),
            stockQuantity = 22,
            isFeatured = true
        ),
        Product(
            id = "prod_co2_45kg",
            name = "OPRONIX Commercial CO2 Fire Extinguisher (4.5 kg)",
            hindiName = "ओप्रोनिक्स व्यावसायिक CO2 अग्निशामक (4.5 किग्रा)",
            category = ProductCategory.CO2_EXTINGUISHER,
            price = 5850.0,
            originalPrice = 6900.0,
            capacity = "4.5 kg Seamless Cylinder",
            description = "Equipped with non-conductive discharge horn and freeze-resistant control valve for data centers and sub-stations.",
            specifications = mapOf(
                "Fire Rating" to "21B",
                "Discharge Duration" to "16 seconds",
                "Discharge Range" to "2 meters"
            ),
            stockQuantity = 18
        ),

        // Foam & Water
        Product(
            id = "prod_foam_9l",
            name = "OPRONIX Mechanical Foam AFFF Extinguisher (9 Litres)",
            hindiName = "ओप्रोनिक्स मैकेनिकल फोम अग्निशामक (9 लीटर)",
            category = ProductCategory.FOAM_EXTINGUISHER,
            price = 2850.0,
            originalPrice = 3400.0,
            capacity = "9 Litres Stored Pressure",
            description = "Aqueous Film Forming Foam (AFFF) for rapid smothering of Class B flammable liquid fires (petrol, diesel, oils, solvents).",
            specifications = mapOf(
                "Concentrate" to "AFFF 6% Concentrate (IS 4989)",
                "Fire Rating" to "3A : 34B",
                "Internal Coating" to "Plastic lining anti-corrosive"
            ),
            stockQuantity = 28
        ),
        Product(
            id = "prod_water_9l",
            name = "OPRONIX Water Fire Extinguisher (9 Litres)",
            hindiName = "ओप्रोनिक्स वाटर अग्निशामक (9 लीटर)",
            category = ProductCategory.WATER_EXTINGUISHER,
            price = 2450.0,
            originalPrice = 2950.0,
            capacity = "9 Litres Water",
            description = "Targeted cooling action for Class A fires involving solid combustibles like paper, wood, packaging, and textiles.",
            specifications = mapOf(
                "Fire Rating" to "3A",
                "Discharge Duration" to "60 seconds",
                "Throw Distance" to "6 meters"
            ),
            stockQuantity = 25
        ),

        // Smoke & Heat Detectors
        Product(
            id = "prod_smoke_sensor",
            name = "OPRONIX Optical Photoelectric Smoke Detector",
            hindiName = "ओप्रोनिक्स ऑप्टिकल फोटोइलेक्ट्रिक धुआं डिटेक्टर",
            category = ProductCategory.SMOKE_DETECTOR,
            price = 850.0,
            originalPrice = 1100.0,
            capacity = "Standard 2-Wire / 4-Wire Base",
            description = "High precision chamber with infrared LED scattering for early detection of smoldering fires. Microprocessor controlled with 360-degree viewing angle.",
            specifications = mapOf(
                "Operating Voltage" to "9V - 33V DC",
                "Standby Current" to "45 microamps",
                "Certification" to "EN 54-7 / UL Listed compliant design",
                "Coverage Area" to "60 sq. meters"
            ),
            stockQuantity = 120,
            isFeatured = true
        ),
        Product(
            id = "prod_heat_detector",
            name = "OPRONIX Dual Rate-of-Rise & Fixed Temp Heat Sensor",
            hindiName = "ओप्रोनिक्स ड्यूल हीट सेंसर",
            category = ProductCategory.HEAT_DETECTOR,
            price = 780.0,
            originalPrice = 980.0,
            capacity = "58°C Fixed + 8.3°C/min RoR",
            description = "Designed for dusty, steamy, or kitchen environments where smoke detectors might trigger false alarms.",
            specifications = mapOf(
                "Alarm Threshold" to "58°C (136°F)",
                "Reset Mechanism" to "Auto-restoring bimetal & thermistor"
            ),
            stockQuantity = 90
        ),

        // Fire Alarm Panels & Hooters
        Product(
            id = "prod_alarm_panel_4z",
            name = "OPRONIX Microprocessor 4-Zone Fire Alarm Panel",
            hindiName = "ओप्रोनिक्स माइक्रोप्रोसेसर 4-ज़ोन फायर अलार्म पैनल",
            category = ProductCategory.ALARM_PANEL,
            price = 11800.0,
            originalPrice = 14500.0,
            capacity = "4 Monitored Detection Zones",
            description = "Central command panel with zone-wise fault and fire indication, internal 24V charger, battery backup, and relay outputs for hooters.",
            specifications = mapOf(
                "Mains Input" to "230V AC ± 10%, 50Hz",
                "Standby Battery" to "2 x 12V 7Ah Sealed Lead Acid",
                "Capacity" to "Up to 25 detectors per zone",
                "Display" to "16x2 Backlit LCD with membrane keypad"
            ),
            stockQuantity = 15,
            isFeatured = true
        ),
        Product(
            id = "prod_hooter_strobe",
            name = "OPRONIX Dual Fire Alarm Electronic Sounder / Hooter",
            hindiName = "ओप्रोनिक्स फायर अलार्म इलेक्ट्रॉनिक साउंडर / हूटर",
            category = ProductCategory.ALARM_HOOTER,
            price = 950.0,
            originalPrice = 1250.0,
            capacity = "105 dB High Sounder Output",
            description = "High decibel acoustic warning device with bright red flashing LED strobe for noisy industrial plants and long corridors.",
            specifications = mapOf(
                "Sound Output" to "105 dB at 1 meter",
                "Voltage" to "24V DC",
                "IP Rating" to "IP54 weather-resistant"
            ),
            stockQuantity = 75
        ),

        // Sprinklers & Hydrants
        Product(
            id = "prod_sprinkler_pendant",
            name = "OPRONIX Glass Bulb Automatic Fire Sprinkler (68°C)",
            hindiName = "ओप्रोनिक्स ग्लास बल्ब स्वचालित फायर स्प्रिंकलर (68°C)",
            category = ProductCategory.SPRINKLER_SYSTEM,
            price = 380.0,
            originalPrice = 490.0,
            capacity = "1/2 inch NPT Pendant Type",
            description = "Thermal glass bulb responsive sprinkler head, red color liquid rated for 68°C. Brass forged body with precision deflector.",
            specifications = mapOf(
                "K-Factor" to "K 5.6 (80 metric)",
                "Working Pressure" to "12 bar maximum",
                "Response" to "Standard Response (5mm bulb)"
            ),
            stockQuantity = 200
        ),
        Product(
            id = "prod_hose_reel_30m",
            name = "OPRONIX Swinging Type Fire Hose Reel with 30m Thermoplastic Hose",
            hindiName = "ओप्रोनिक्स 30 मीटर फायर होज़ रील",
            category = ProductCategory.HOSE_REEL,
            price = 6200.0,
            originalPrice = 7500.0,
            capacity = "30 meters / 19mm bore",
            description = "Heavy duty 180-degree swinging arm drum conforming to IS 884 with bronze shut-off jet/spray nozzle.",
            specifications = mapOf(
                "Hose Length" to "30 meters",
                "Bursting Pressure" to "30 kgf/cm²",
                "Drum Material" to "Mild steel sheet cold rolled"
            ),
            stockQuantity = 14
        ),
        Product(
            id = "prod_hydrant_valve",
            name = "OPRONIX Single Head Oblique Fire Hydrant Landing Valve",
            hindiName = "ओप्रोनिक्स सिंगल हेड लैंडिंग वाल्व",
            category = ProductCategory.HYDRANT_EQUIPMENT,
            price = 4800.0,
            originalPrice = 5700.0,
            capacity = "63mm Female Instantaneous Outlet",
            description = "Gunmetal / Stainless Steel body conforming to IS 5290 with blank cap and chain, handwheel operated.",
            specifications = mapOf(
                "Inlet Size" to "75mm or 80mm Flanged",
                "Outlet Size" to "63mm standard instantaneous",
                "Hydrostatic Test" to "21 kgf/cm²"
            ),
            stockQuantity = 16
        ),

        // Signage, Lights, Blankets & Accessories
        Product(
            id = "prod_safety_signage",
            name = "OPRONIX Photoluminescent Glow Fire Extinguisher Sign Board",
            hindiName = "ओप्रोनिक्स ग्लो-इन-द-डार्क फायर सुरक्षा साइन बोर्ड",
            category = ProductCategory.SAFETY_SIGNAGE,
            price = 280.0,
            originalPrice = 390.0,
            capacity = "20cm x 30cm Self-Adhesive Rigid PVC",
            description = "Long glow afterglow photoluminescent sign ensuring visibility during power failure and smoke evacuation.",
            specifications = mapOf(
                "Material" to "2mm Glow Rigid Sheet",
                "Afterglow Time" to "> 8 hours",
                "Standard" to "ISO 7010 & DIN 67510"
            ),
            stockQuantity = 150
        ),
        Product(
            id = "prod_emergency_light",
            name = "OPRONIX Automatic Twin-Spot Rechargeable Emergency LED Light",
            hindiName = "ओप्रोनिक्स ऑटोमैटिक ट्विन-स्पॉट इमरजेंसी एलईडी लाइट",
            category = ProductCategory.EMERGENCY_LIGHT,
            price = 1950.0,
            originalPrice = 2490.0,
            capacity = "3 Hours Autonomous Backup",
            description = "High intensity multi-directional LED spot lamps with SMPS battery charger, auto on/off sensor during blackouts.",
            specifications = mapOf(
                "LED Power" to "2 x 3W High Output Cree LEDs",
                "Battery" to "3.7V 4400mAh Lithium Ion",
                "Recharge Time" to "10 hours"
            ),
            stockQuantity = 40
        ),
        Product(
            id = "prod_fire_blanket",
            name = "OPRONIX Fiberglass Emergency Fire Blanket (1.8m x 1.8m)",
            hindiName = "ओप्रोनिक्स फाइबरग्लास इमरजेंसी फायर ब्लैंकेट",
            category = ProductCategory.FIRE_BLANKET,
            price = 890.0,
            originalPrice = 1200.0,
            capacity = "1.8m x 1.8m in Quick Release Bag",
            description = "Woven fiberglass cloth with silicone coating capable of withstanding temperatures up to 550°C. Perfect for kitchens and clothing fires.",
            specifications = mapOf(
                "Material" to "100% Woven Fiberglass Fabric",
                "Standard" to "EN 1869:1997 certified",
                "Release" to "Quick pull flameproof straps"
            ),
            stockQuantity = 85
        ),
        Product(
            id = "prod_accessories_stand",
            name = "OPRONIX Heavy-Duty Universal Fire Extinguisher Floor Stand",
            hindiName = "ओप्रोनिक्स यूनिवर्सल फ्लोर स्टैंड",
            category = ProductCategory.ACCESSORIES,
            price = 1450.0,
            originalPrice = 1850.0,
            capacity = "Holds up to 9kg or 9L Extinguishers",
            description = "Corrosion resistant powder-coated tubular steel stand for marble, tiled or rented offices where wall drilling is prohibited.",
            specifications = mapOf(
                "Finish" to "Epoxy Polyester Signal Red Powder Coat",
                "Base" to "Rubber foot grips"
            ),
            stockQuantity = 50
        )
    )

    private fun createInitialOrders(): List<Order> = listOf(
        Order(
            id = "ORD-2026-8812",
            invoiceNumber = "OPR-INV-2026-8812",
            customerId = "usr_demo_1",
            customerName = "Rajesh Sharma",
            customerPhone = "+91 98290 12345",
            orderDateMillis = System.currentTimeMillis() - 86400000L * 2,
            items = listOf(
                CartItem(createInitialProducts()[0], 4),
                CartItem(createInitialProducts()[3], 2)
            ),
            subtotal = 14300.0,
            gstAmount = 2574.0,
            deliveryFee = 250.0,
            discount = 500.0,
            totalAmount = 16624.0,
            deliveryAddress = Address(
                id = "addr_1",
                label = "Corporate Office",
                street = "Plot 42, Sitapura Industrial Area",
                city = "Jaipur",
                state = "Rajasthan",
                pincode = "302022"
            ),
            status = OrderStatus.PROCESSING,
            paymentMethod = PaymentMethod.PAY_ON_INVOICE,
            paymentStatus = PaymentStatus.DEMO_VERIFIED,
            trackingNotes = listOf(
                TrackingUpdate("Order placed successfully via OPRONIX Demo", System.currentTimeMillis() - 86400000L * 2),
                TrackingUpdate("Commercial invoice generated & order confirmed", System.currentTimeMillis() - 86400000L),
                TrackingUpdate("Warehouse packing and inspection in progress", System.currentTimeMillis() - 3600000L * 5)
            )
        )
    )

    private fun createInitialBookings(): List<ServiceBooking> = listOf(
        ServiceBooking(
            id = "SB-2026-104",
            bookingNumber = "OPR-SRV-104",
            serviceType = ServiceType.EXTINGUISHER_REFILLING,
            customerId = "usr_demo_1",
            customerName = "Rajesh Sharma",
            customerPhone = "+91 98290 12345",
            siteAddress = "Plot 42, Sitapura Industrial Area, Jaipur",
            propertyType = PropertyType.INDUSTRIAL_FACTORY,
            preferredDate = "28 Oct 2026",
            preferredTimeSlot = "10:00 AM - 1:00 PM",
            equipmentType = "ABC 4kg (8 units) & CO2 4.5kg (4 units)",
            estimatedUnits = 12,
            problemDescription = "Annual hydro-testing and refilling due as per factory safety compliance audit.",
            status = BookingStatus.TECHNICIAN_ASSIGNED,
            assignedTechnicianId = "tech_01",
            assignedTechnicianName = "Vikram Singh",
            assignedTechnicianPhone = "+91 98291 99887",
            estimatedCost = 5400.0,
            technicianNotes = "Site visit scheduled. Pressure testing equipment mobilized."
        )
    )

    private fun createInitialQuotations(): List<Quotation> = listOf(
        Quotation(
            id = "QT-2026-551",
            quoteReference = "OPR-EST-551",
            customerId = "usr_demo_1",
            customerName = "Rajesh Sharma",
            companyName = "Sharma Enterprises Pvt Ltd",
            email = "rajesh.sharma@example.com",
            phone = "+91 98290 12345",
            siteAddress = "Plot 42, Sitapura Industrial Area, Jaipur",
            requirements = "Complete turnkey fire detection system installation for new 12,000 sq.ft assembly shed, including 4-Zone control panel, 24 optical smoke sensors, and 4 manual call points with hooters.",
            requestedItems = listOf(
                QuotationItem("Turnkey Smoke Detection System", "24 sensors + 4 Zone panel", 1, 38500.0)
            ),
            status = QuotationStatus.QUOTATION_PREPARED,
            quotedSubtotal = 38500.0,
            quotedGst = 6930.0,
            quotedGrandTotal = 45430.0,
            adminNotes = "Special corporate discount applied. Turnkey testing and commissioning included."
        )
    )

    private fun createInitialContracts(): List<AmcContract> = listOf(
        AmcContract(
            id = "AMC-2026-001",
            contractNumber = "OPR-AMC-882",
            customerId = "usr_demo_1",
            customerName = "Rajesh Sharma",
            companyName = "Sharma Enterprises Pvt Ltd",
            tier = AmcTier.COMMERCIAL_PRO,
            siteAddress = "Plot 42, Sitapura Industrial Area, Jaipur",
            coveredEquipmentsCount = 35,
            quarterlyAuditsDone = 2,
            totalQuarterlyAudits = 4,
            startDate = "01 Jan 2026",
            renewalDate = "31 Dec 2026",
            annualFee = 24999.0,
            status = AmcStatus.ACTIVE
        )
    )

    private fun createInitialNotifications(): List<NotificationItem> = listOf(
        NotificationItem(
            id = "notif_1",
            title = "Order Processing Update",
            hindiTitle = "ऑर्डर अपडेट",
            message = "Order #ORD-2026-8812 is being prepared for dispatch from Jaipur central hub.",
            timestampMillis = System.currentTimeMillis() - 1000 * 60 * 60 * 3,
            type = NotificationType.ORDER,
            referenceId = "ORD-2026-8812"
        ),
        NotificationItem(
            id = "notif_2",
            title = "Technician Assigned",
            hindiTitle = "तकनीशियन नियुक्त",
            message = "Field Engineer Vikram Singh has been assigned for your refilling request #OPR-SRV-104.",
            timestampMillis = System.currentTimeMillis() - 1000 * 60 * 60 * 24,
            type = NotificationType.SERVICE,
            referenceId = "SB-2026-104"
        ),
        NotificationItem(
            id = "notif_3",
            title = "Official Quotation Ready",
            hindiTitle = "कोटेशन तैयार है",
            message = "Quotation #OPR-EST-551 for ₹45,430 is ready for review.",
            timestampMillis = System.currentTimeMillis() - 1000 * 60 * 60 * 48,
            type = NotificationType.QUOTATION,
            referenceId = "QT-2026-551"
        )
    )
}
