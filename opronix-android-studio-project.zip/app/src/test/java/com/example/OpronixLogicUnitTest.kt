package com.example

import com.example.data.DemoRepository
import com.example.model.*
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test

class OpronixLogicUnitTest {

    private val sampleProduct1 = Product(
        id = "prod_test_1",
        name = "ABC Fire Extinguisher 4kg",
        category = ProductCategory.ABC_EXTINGUISHER,
        price = 2000.0,
        capacity = "4 kg"
    )

    private val sampleProduct2 = Product(
        id = "prod_test_2",
        name = "Optical Smoke Sensor",
        category = ProductCategory.SMOKE_DETECTOR,
        price = 1000.0,
        capacity = "Dual Wire"
    )

    @Test
    fun testCartPricingCalculations_withoutCoupon() {
        val items = listOf(
            CartItem(sampleProduct1, quantity = 2), // 2 * 2000 = 4000
            CartItem(sampleProduct2, quantity = 1)  // 1 * 1000 = 1000
        )
        val summary = CartSummary(items = items, couponDiscount = 0.0, deliveryFee = 250.0)

        assertEquals(5000.0, summary.subtotal, 0.01)
        // GST 18% on 5000 = 900
        assertEquals(900.0, summary.gstAmount, 0.01)
        // Grand Total = 5000 + 900 + 250 = 6150
        assertEquals(6150.0, summary.grandTotal, 0.01)
        assertEquals(3, summary.totalItemCount)
    }

    @Test
    fun testCartPricingCalculations_withCouponDiscount() {
        val items = listOf(
            CartItem(sampleProduct1, quantity = 2) // 4000
        )
        val discount = 400.0 // 10% coupon discount
        val summary = CartSummary(items = items, couponDiscount = discount, deliveryFee = 250.0)

        assertEquals(4000.0, summary.subtotal, 0.01)
        // GST 18% on (4000 - 400 = 3600) = 648
        assertEquals(648.0, summary.gstAmount, 0.01)
        // Grand Total = 3600 + 648 + 250 = 4498
        assertEquals(4498.0, summary.grandTotal, 0.01)
    }

    @Test
    fun testInputValidation_indianPhoneAndEmail() {
        val validPhone1 = "+91 98290 12345"
        val validPhone2 = "9829012345"
        val invalidPhone = "12345"

        val validEmail = "operations@opronix.in"
        val invalidEmail = "operationsopronix.in"

        assertTrue(validPhone1.filter { it.isDigit() }.takeLast(10).length == 10)
        assertTrue(validPhone2.filter { it.isDigit() }.takeLast(10).length == 10)
        assertFalse(invalidPhone.filter { it.isDigit() }.takeLast(10).length == 10)

        assertTrue(validEmail.contains("@") && validEmail.contains("."))
        assertFalse(invalidEmail.contains("@"))
    }

    @Test
    fun testDemoRepository_productMutationAndOrderLifecycle() = runBlocking {
        val repo = DemoRepository()

        val initialProducts = repo.products.first()
        assertTrue(initialProducts.isNotEmpty())

        val newProduct = Product(
            id = "prod_custom_99",
            name = "Automatic Clean Agent Ceiling Extinguisher 5kg",
            category = ProductCategory.ABC_EXTINGUISHER,
            price = 4500.0,
            capacity = "5 kg Ceiling Mount"
        )
        repo.addProduct(newProduct)

        val updatedProducts = repo.products.first()
        assertTrue(updatedProducts.any { it.id == "prod_custom_99" })

        // Place an order
        val address = Address(street = "Test Street", city = "Jaipur", pincode = "302022")
        val orderResult = repo.placeOrder(
            items = listOf(CartItem(newProduct, 2)),
            deliveryAddress = address,
            paymentMethod = PaymentMethod.PAY_ON_INVOICE,
            discount = 0.0
        )
        assertTrue(orderResult.isSuccess)
        val order = orderResult.getOrThrow()
        assertEquals(OrderStatus.PENDING, order.status)

        // Advance status to Confirmed
        repo.updateOrderStatus(order.id, OrderStatus.CONFIRMED, "Order confirmed by OPRONIX operations")
        val updatedOrder = repo.getOrderById(order.id)
        assertNotNull(updatedOrder)
        assertEquals(OrderStatus.CONFIRMED, updatedOrder?.status)
    }

    @Test
    fun testDemoRepository_technicianAssignmentAndQuotation() = runBlocking {
        val repo = DemoRepository()

        val initialBookings = repo.bookings.first()
        assertTrue(initialBookings.isNotEmpty())
        val booking = initialBookings.first()

        repo.assignTechnician(booking.id, "tech_02", "Deepak Verma", "+91 98292 11223")
        val updatedBooking = repo.getBookingById(booking.id)
        assertEquals("Deepak Verma", updatedBooking?.assignedTechnicianName)
        assertEquals(BookingStatus.TECHNICIAN_ASSIGNED, updatedBooking?.status)

        // Quotations
        val initialQuotes = repo.quotations.first()
        assertTrue(initialQuotes.isNotEmpty())
        val quote = initialQuotes.first()

        repo.updateQuotation(
            quoteId = quote.id,
            status = QuotationStatus.QUOTATION_PREPARED,
            subtotal = 50000.0,
            gst = 9000.0,
            grandTotal = 59000.0,
            adminNotes = "Approved with turnkey testing"
        )
        val updatedQuote = repo.getQuotationById(quote.id)
        assertEquals(QuotationStatus.QUOTATION_PREPARED, updatedQuote?.status)
        assertEquals(59000.0, updatedQuote?.quotedGrandTotal ?: 0.0, 0.01)
    }
}
